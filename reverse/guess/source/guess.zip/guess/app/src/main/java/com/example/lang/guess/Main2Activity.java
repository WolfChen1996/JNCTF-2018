package com.example.lang.guess;

import android.content.Intent;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.BatchUpdateException;
import java.util.Random;

public class Main2Activity extends AppCompatActivity {
    private TextView textView;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView=findViewById(R.id.textView3);
        int a=RandomUntil.getNum(1,99);
        int b=RandomUntil.getNum(1,99);
        int c=RandomUntil.getNum(1,99);
        int d=RandomUntil.getNum(1,99);
        textView.setText(getString(R.string.question2,a,b,c,d));
        int answer=a*b+c-d;
        final Intent i=new Intent(Main2Activity.this,Main3Activity.class);
        i.putExtra("VERIFY",answer);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText=(EditText)findViewById(R.id.editText);
                String et=editText.getText().toString();

                if (et.equals("talent")){
                    Toast.makeText(Main2Activity.this,"Well done.",Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }else {
                    Toast.makeText(Main2Activity.this,"NO",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

