package com.example.lang.guess;

import android.content.res.Resources;
import android.renderscript.Element;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Main3Activity extends AppCompatActivity {
    private Button button;
    private TextView textView;
    private EditText editText;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /**
         * 从上一Activity获取参数用以确定具体使用哪一密钥
         */
        editText = (EditText) findViewById(R.id.editText3);
        button = (Button) findViewById(R.id.button2);
        textView = (TextView) findViewById(R.id.enc_flag);
        setContentView(R.layout.activity_main3);
        final int data = (int) getIntent().getIntExtra("VERIFY", 0);
        /**
         * 四串密钥
         */
        final String key0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        final String key1 = "+/abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        final String key2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/";
        final String key3 = "0123456789+/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        /**
         * 第一步运算使用的字符串
         */
        final char[] reserve = {'E', 'A', 'B', 'H', 'E', 'H', 'B', '2', 'O', '0', 'G', '9', 'P', 'M', 'G', 'K', 'Q', 'X', 'Z', 'H', 'A', 'S', 'T', 'V'};
        /**
         * 生成随机字符串 没啥卵用 看起来好看
         */
        StringRandom test = new StringRandom();
        final String longmap = test.getStringRandom(200);
        /**
         * 先用早已确定好的结果走一遍过场
         */
        final char[] first = new char[24];
        final int[][] dict = {{70, 78, 66, 77, 100, 108, 47, 107, 47, 78},
                {66, 122, 109, 118, 65, 74, 66, 47, 66, 73},
                {110, 66, 110, 117, 39, 58, 102, 117, 39, 49},
                {37, 52, 55, 4, 61, 89, 95, 30, 26, 38},
                {57, 63, 47, 26, 666, 666, 53, 66, 49, 65},
                {42, 38, 22, 40, 666, 666, 49, 110, 97, 106},
                {102, 110, 98, 109, 98, 90, 98, 49, 98, 105},
                {77, 86, 78, 98, 78, 85, 45, 44, 88, 58},
                {37, 52, 55, 4, 57, 63, 41, 39, 39, 125},
                {47, 26, 42, 38, 22, 40, 20, 99, 14, 87}};
        final int[] route = new int[24];

        switch (data % 4) {
            case 0:
                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 4; j++) {
                        route[4 * i + j] = dict[i][j];
                    }
                }
                break;
            case 1:
                for (int i = 0; i < 4; i++) {
                    for (int j = 5; j < 10; j++) {
                        route[(10 - 5) * i + j - 5] = dict[i][j];
                    }
                }
                break;
            case 2:
                for (int i = 6; i < 10; i++) {
                    for (int j = 0; j < 6; j++) {
                        route[6 * (i - 6) + j] = dict[i][j];
                    }
                }
                break;
            case 3:
                for (int i = 4; i < 10; i++) {
                    for (int j = 6; j < 10; j++) {
                        route[(10 - 6) * (i - 4) + j - 6] = dict[i][j];
                    }
                }
                break;
        }
        for (int i = 0; i < 24; i++) {
            first[i] = longmap.toCharArray()[route[i]];
        }
        /**
         * 显示Hint
         */
        textView.setText(new String(first));
        /**
         * 按钮事件
         */
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String et = editText.getText().toString();
                char[] input = null;
                char[] temp1 = new char[24];
                int[] temp2 = new int[24];
                char[] temp3 = new char[24];
                input = et.toCharArray();
                int length = input.length;
                /**
                 * 检查输入字符串长度是否为24
                 */
                if (length != 24) {
                    Toast.makeText(Main3Activity.this, "No.", Toast.LENGTH_SHORT).show();
                } else {
                    /**
                     * 确定密钥
                     */
                    int choice = data % 4;
                    String[] selectedKey = {key0, key1, key2, key3};
                    for (int i = 0; i < 24; i++) {
                        try {
                            /**
                             * 在密钥中查找flag-reserve值所对应的字符
                             */
                            temp1[i] = selectedKey[choice].toCharArray()[(input[i] - reserve[i])];
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(Main3Activity.this, "Try again.", Toast.LENGTH_SHORT).show();
                        }
                        /**
                         *  将找到的字符串头尾进行异或
                         */
                        temp2[i] = (temp1[i] ^ temp1[23 - i]);
                        /**
                         * 得到的值对应随机生成的字符
                         */
                        temp3[i] = longmap.toCharArray()[route[i]];
                    }
                    /**
                     * 运算之后与之前走的过场比较。
                     */
                    if (new String(temp3).equals(new String(first))) {
                        Toast.makeText(Main3Activity.this, "Congratulations!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Main3Activity.this, "Try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
