#include "Living.h"
#include "arith.h"
#include <windows.h>
#include "CommonHead.h"

#ifndef _D2DRender_
#include "Animation.h"
#else
#endif


#ifndef _H_PLAYER_H
#define _H_PLAYER_H
#pragma once



#define MAX_PLAYER_STATE 20		//������״̬
#define MAX_PLAYER_WEAPON 20		//����������
#define MAX_PLAYER_SKILL 6			//�����༼��
#define MAX_PLAYER_GOODS 256






class CPlayer:public CLiving{
public:
	CPlayer(void);
	CPlayer(int _hp, int _attack, int _defense, int _swift);

	~CPlayer(void);

	void LoadHero(int* p);


	//bool Render();
	void EatItem(char _block);


	int	GetLevel();
	void LevelUp(int _level);

	int	GetExp();
	void EarnExp(int _exp);

	int	GetHP();
	void EarnHP(int _hp);


	int	GetAttack();
	void	EarnAttack(int _attack);

	int GetCombo();
	void IncreaseCombo(int _combo);

	int	GetDefense();
	void EarnDefense(int _defense);

	int	GetSwift();
	void EarnSwift(int _swift);

	int GetCritical();
	void SetCritical(int _critical);

	int GetCriticalRatio();
	void SetCriticalRatio(int _criticalratio);

	int GetHemophagia();
	void SetHemophagia(int _hemophagia);




	map<char, int>				m_mItem;

protected:

	int				m_nLevel;
	int				m_nExp;

	int				m_nHP;//Ѫ��


	int				m_nAttack;
	int				m_nDefense;
	int				m_nCombo;//����
	int				m_nSwift;

	int				m_nCritical;
	int				m_nCriticalRatio;
	int				m_nHemophagia;


	bool							m_bLocalPlayer;//�Լ������ϵ���� ��Ҫʹ�ü�����Դ �������remoteplayer

	vector	<PLAYERSTATE>	m_vState;//���״̬;
	vector	<WEAPON>			m_vWeapon;//����ӵ�е�����
	vector	<SKILL>			m_vSkill;//����ӵ�еļ���
	//set	<ITEM>				m_vItem;//�����Ʒ
	

};







#endif