#include "Arith.h"
#include "Player.h"
#ifndef _H_BEHAVIOUR_H
#define _H_BEHAVIOUR_H
#pragma once





class CBehaviour{
public:
	CBehaviour(void);
	~CBehaviour(void);

	bool Execute(float fTime);

	bool Move(CPlayer &oPlayer, float fTime);

};







#endif