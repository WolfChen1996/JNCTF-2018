#include "stdafx.h"
#include "Player.h"

CPlayer::CPlayer(){
	m_nLevel = 1;
	m_nExp = 0;

	//m_mMoveAnimation.insert()
}

CPlayer::CPlayer(int _hp, int _attack, int _defense, int _swift)
	:m_nHP(_hp),m_nAttack(_attack),m_nDefense(_defense),m_nSwift(_swift){
	
	m_nLevel = 1;
	m_nExp = 0;

}
CPlayer::~CPlayer(){


}

void CPlayer::LoadHero(int* p){
	
	int *pBuff[] = {
		&m_nFloor,
		&m_nPos.x,
		&m_nPos.y,
		&m_nHP,
		&m_nAttack,
		&m_nDefense,
		&m_nSwift,
		&m_nCombo,
		&m_nCritical,
		&m_nCriticalRatio,
		&m_nHemophagia,
		&m_nLevel,
		&m_nExp
	};


	for (int i = 0; i < sizeof(pBuff) / sizeof(int*); i++){
		*pBuff[i] = p[i];
	}


}
void CPlayer::EatItem(char _block){
	switch (_block)	{
	case (char)225://key1

		break;

	case (char)230://potion1
		
		break;
	default:
		break;
	}

}

int	CPlayer::GetLevel(){
	return m_nLevel;
}

void CPlayer::LevelUp(int _level){
	m_nLevel += _level;
}


int	CPlayer::GetExp(){
	return m_nExp;
}

void CPlayer::EarnExp(int _exp){
	m_nExp += _exp;
}

int	CPlayer::GetHP(){
	return m_nHP;
}

void CPlayer::EarnHP(int _hp){
	m_nHP += _hp;
}



int	CPlayer::GetAttack(){
	return m_nAttack;

}

void	CPlayer::EarnAttack(int _attack){
	m_nAttack += _attack;
}

int CPlayer::GetCombo(){
	return m_nCombo;

}
void CPlayer::IncreaseCombo(int _combo){
	m_nCombo += _combo;

}

int	CPlayer::GetDefense(){
	return m_nDefense;
}

void CPlayer::EarnDefense(int _defense){
	m_nDefense += _defense;
}


int	CPlayer::GetSwift(){
	return m_nSwift;
}

void CPlayer::EarnSwift(int _swift){
	m_nSwift += _swift;
}

int CPlayer::GetCritical(){
	return m_nCritical;
}
void CPlayer::SetCritical(int _critical){
	m_nCritical = _critical;
}

int CPlayer::GetCriticalRatio(){
	return m_nCriticalRatio;
}
void CPlayer::SetCriticalRatio(int _criticalratio){
	m_nCriticalRatio = _criticalratio;
}

int CPlayer::GetHemophagia(){
	return m_nHemophagia;
}
void CPlayer::SetHemophagia(int _hemophagia){
	m_nHemophagia = _hemophagia;
}



/*bool CPlayer::Render(){

	return true;
}*/