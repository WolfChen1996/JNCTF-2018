#include "stdafx.h"
#include "Game.h"
#include "File.h"
#include "DSound.h"
#include "resource.h"
#include "CRC.h"

#pragma warning (disable: 4996) 
#pragma warning (disable: 4244) 
#pragma warning (disable: 4258) 

using namespace DSound;
using namespace Arith;

CBehaviour Behaviour;

int DEBUG_BATTLE_X=0;
int DEBUG_BATTLE_Y=0;


//#ifdef DBG
CPlayer Hero(INIT_HP, INIT_ATTACK, INIT_DEFENSE, INIT_SWIFT);
//CSound Sound;
//#endif


HANDLE RenderMutex;//��Ⱦ�Ļ�����


CGame::CGame(){
	
	m_fTime = 0;
	m_vResolution = GetScreenResolution();
	m_fUnitScale = fVector(1.0f, 1.0f);
	RenderMutex = CreateSemaphore(NULL, 1, 1, NULL);

	m_gameState = GAME_LOADING;

#ifdef _D2DRender_

	//m_bEmployHardwareRender = true;
#else
	//m_bEmployHardwareRender = false;
#endif

	memset(m_KeyState, 0, sizeof(m_KeyState));//������Ϣ����


}

CGame::~CGame(){
	CloseHandle(RenderMutex);
}
//��Ϸ��ʼ��
bool CGame::InitGame(HWND hWnd){

	CheckCRC("Data\\1.map", 0xB342A835);
	CheckCRC("Data\\2.map", 0xDF9FC3BE );
	CheckCRC("Data\\3.map", 0x87A3481E );
	CheckCRC("Data\\4.map", 0x61AA60C4 );
	CheckCRC("Data\\5.map", 0xBB2EE111 );
	CheckCRC("Data\\6.map", 0xB266333C );
	CheckCRC("Data\\7.map", 0xA19FBFEB );
	CheckCRC("Data\\8.map", 0x53E0E986 );
	CheckCRC("Data\\9.map", 0x91D5AE7 );
	CheckCRC("Data\\10.map", 0x958F11F0 );
	CheckCRC("Data\\monster.dat", 0x2EF1DD68 );























#ifdef MAP_LARGE
	//���Ը��ĵ����зֱ���
	m_ResolutionSetting.nResolutionNow = 0;
	m_ResolutionSetting.vResolution.push_back(Vector(735, 580));
	m_ResolutionSetting.vResolution.push_back(Vector(973, 768));
	m_ResolutionSetting.vResolution.push_back(Vector(1242, 980));
	m_ResolutionSetting.vResolution.push_back(Vector(1366, 1078));//1920*1080
	m_ResolutionSetting.vResolution.push_back(Vector(1700, 1331));
#else
	m_ResolutionSetting.nResolutionNow = 0;
	m_ResolutionSetting.vResolution.push_back(Vector(635,485));
	m_ResolutionSetting.vResolution.push_back(Vector(889, 679));
	m_ResolutionSetting.vResolution.push_back(Vector(1005, 768));
	m_ResolutionSetting.vResolution.push_back(Vector(1245, 951));
	m_ResolutionSetting.vResolution.push_back(Vector(1414, 1080));
	m_ResolutionSetting.vResolution.push_back(Vector(1700, 1331));
#endif
	
	Sleep(10);
	WaitForSingleObject(RenderMutex, INFINITE);

	m_mD2DImage["loadback"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 12.png");

	m_mD2DImage["load1"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 70.png");
	m_mD2DImage["load2"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 71.png");
	m_mD2DImage["load3"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 72.png");
	m_mD2DImage["load4"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 73.png");
	m_mD2DImage["load5"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 74.png");
	m_mD2DImage["load6"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 75.png");
	m_mD2DImage["load7"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 76.png");
	m_mD2DImage["load8"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 77.png");
	m_mD2DImage["load9"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 78.png");
	m_mD2DImage["load10"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 79.png");
	m_mD2DImage["load11"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 80.png");
	m_mD2DImage["load12"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 81.png");
	m_mD2DImage["load13"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 82.png");

	m_mD2DGif["loading"].AddImage(m_mD2DImage["load1"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load2"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load3"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load4"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load5"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load6"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load7"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load8"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load9"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load10"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load11"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load12"], Vector(206, 60));
	m_mD2DGif["loading"].AddImage(m_mD2DImage["load13"], Vector(206, 60));

	m_mD2DGif["loading"].SetFPS(48);
	m_mD2DGif["loading"].SetCycles(INF);
	m_mD2DGif["loading"].Reset();
	
	if (!LoadRes())return false;
	ReleaseSemaphore(RenderMutex, 1, NULL);

////////////////////////////
//
// ��ʼ��Ӣ��//////////////////

	if (!InitHero())return false;

////////////////////////////
//
//
////////////////////////////

///////////////////////////
//
//��ʼ����Ϸ״̬//////////////
#ifdef DEBUG_PLAY
	
#else
	Sleep(750);
#endif
	m_gameState = GAME_RUNNING;

	m_subState.nShopNeedGold = 20;

	//m_gameState = GAME_STATE::GAME_CAPTION;
	//m_gameState = GAME_STATE::GAME_MAIN_MENU;

///////////////////////////
//
///////////////////////////



	return true;
}


#define LoadImg(alias,path)  	m_mD2DImage.insert(pair<string, CD2DImage>(alias, d2dImageBuf));m_mD2DImage[alias].LoadImageFromFile(D2DC.pRenderTarget(), TEXT(path));
//#define LoadBlock(alias,value) 	m_mBlock.insert(pair<string, char>(alias, (char)value));


//��ʼ��Ӣ��
bool CGame::InitHero(){

/////////////////
//��ʼ����λ��
	Hero.SetDirection(INIT_DIRECTION);
	Hero.SetPosition(Point(INIT_X, INIT_Y));
	Hero.SetFloor(INIT_FLOOR);

	Hero.m_mItem[(char)225] = 1;
	Hero.m_mItem[(char)226] = 1;
	Hero.m_mItem[(char)227] = 1;

	return true;
}
#ifdef DEBUG_PLAY

#define LOADING_DELAY 0
#else
#define LOADING_DELAY 25

#endif
//////////////////////
//
//
// ������Դ ��Ч ���� ���ݵȵ�
//
//////////////////////
bool CGame::LoadRes(){




	CD2DImage d2dImageBuf;

	CD2DGif d2dGifBuf(GIF_FPS);
	
	CD2DGif d2dBattleBuf(BATTLE_FPS);



	m_mD2DImage.insert(pair<string, CD2DImage>("flag", d2dImageBuf));
	m_mD2DImage["flag"].LoadImageFromRes(D2DC.pRenderTarget(), m_Instance, IDB_PNG1, L"png");


	//m_mD2DImage.insert(pair<string, CD2DImage>("wall", d2dImageBuf));
	//m_mD2DImage["wall"].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 15.png");
	LoadImg("blank", "Images/Image 0.png");
	LoadImg("battleback", "Images/Image 1.png");
	LoadImg("talkback", "Images/Image 2.png");
	LoadImg("pause", "Images/Image 3.png");
	LoadImg("infoback", "Images/Image 4.png");
	LoadImg("backbig", "Images/Image 5.png");
	LoadImg("Dback", "Images/Image 6.png");
	LoadImg("leftarrow", "Images/Image 7.png");
	LoadImg("rightarrow", "Images/Image 8.png");
	LoadImg("uparrow", "Images/Image 9.png");
	LoadImg("downarrow", "Images/Image 10.png");
	LoadImg("battleendback", "Images/Image 11.png");
	LoadImg("transition", "Images/Image 12.png");
	LoadImg("caption", "Images/Image 13.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 3;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("back", "Images/Image 15.png");
	LoadImg("floor", "Images/Image 27.png");
	LoadImg("wall", "Images/Image 686.png");
	LoadImg("star", "Images/Image 689.png");
	LoadImg("magma", "Images/Image 693.png");
	LoadImg("dirt", "Images/Image 697.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 5;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);


	LoadImg("hero1d", "Images/Image 161.png");
	LoadImg("hero1l", "Images/Image 282.png");
	LoadImg("hero1r", "Images/Image 309.png");
	LoadImg("hero1u", "Images/Image 336.png");
	LoadImg("hero1wd1", "Images/Image 263.png");
	LoadImg("hero1wl1", "Images/Image 291.png");
	LoadImg("hero1wr1", "Images/Image 318.png");
	LoadImg("hero1wu1", "Images/Image 345.png");
	LoadImg("hero1wd2", "Images/Image 273.png");
	LoadImg("hero1wl2", "Images/Image 300.png");
	LoadImg("hero1wr2", "Images/Image 327.png");
	LoadImg("hero1wu2", "Images/Image 354.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 7;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("key1", "Images/Image 136.png");
	LoadImg("key2", "Images/Image 139.png");
	LoadImg("key3", "Images/Image 142.png");
	LoadImg("gold", "Images/Image 145.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 9;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("door1", "Images/Image 561.png");
	LoadImg("door12", "Images/Image 562.png");
	LoadImg("door13", "Images/Image 563.png");
	LoadImg("door14", "Images/Image 564.png");
	LoadImg("door15", "Images/Image 565.png");
	
	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 11;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("door2", "Images/Image 569.png");
	LoadImg("door22", "Images/Image 570.png");
	LoadImg("door23", "Images/Image 571.png");
	LoadImg("door24", "Images/Image 572.png");
	LoadImg("door25", "Images/Image 573.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 12;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("door3", "Images/Image 576.png");
	LoadImg("door32", "Images/Image 577.png");
	LoadImg("door33", "Images/Image 578.png");
	LoadImg("door34", "Images/Image 579.png");
	LoadImg("door35", "Images/Image 580.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 15;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("jail", "Images/Image 583.png");
	LoadImg("jail2", "Images/Image 584.png");
	LoadImg("jail3", "Images/Image 585.png");
	LoadImg("jail4", "Images/Image 586.png");
	LoadImg("jail5", "Images/Image 587.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 17;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("door4", "Images/Image 590.png");

	LoadImg("gem1", "Images/Image 597.png");
	LoadImg("gem2", "Images/Image 600.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 18;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("potion1", "Images/Image 603.png");
	LoadImg("potion2", "Images/Image 606.png");
	LoadImg("potion3", "Images/Image 609.png");
	LoadImg("potion4", "Images/Image 612.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 20;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("sword1", "Images/Image 615.png");
	LoadImg("sword2", "Images/Image 618.png");
	LoadImg("sword3", "Images/Image 621.png");
	LoadImg("sword4", "Images/Image 624.png");
	LoadImg("sword5", "Images/Image 627.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 22;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("shield1", "Images/Image 630.png");
	LoadImg("shield2", "Images/Image 633.png");
	LoadImg("shield3", "Images/Image 636.png");
	LoadImg("shield4", "Images/Image 639.png");
	LoadImg("shield5", "Images/Image 642.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 24;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("key4", "Images/Image 645.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 25;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("pickax1", "Images/Image 648.png");
	LoadImg("pickax2", "Images/Image 651.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 26;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("snow", "Images/Image 654.png");
	LoadImg("holyshield", "Images/Image 657.png");
	LoadImg("cross", "Images/Image 660.png");
	LoadImg("wing2", "Images/Image 663.png");
	LoadImg("wing3", "Images/Image 665.png");
	LoadImg("wing1", "Images/Image 668.png");
	LoadImg("badge1", "Images/Image 671.png");
	LoadImg("badge2", "Images/Image 674.png");
	LoadImg("badge3", "Images/Image 677.png");
	LoadImg("holywater", "Images/Image 680.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 28;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);
	LoadImg("gem3", "Images/Image 683.png");

	LoadImg("bramble_1", "Images/Image 834.png");

	LoadImg("bramble_2", "Images/Image 836.png");
	LoadImg("upstairs", "Images/Image 839.png");
	LoadImg("downstairs", "Images/Image 842.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 31;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("merchant_1", "Images/Image 855.png");
	LoadImg("merchant_2", "Images/Image 857.png");
	LoadImg("oldman_1", "Images/Image 860.png");
	LoadImg("oldman_2", "Images/Image 862.png");
	LoadImg("thief_1", "Images/Image 865.png");
	LoadImg("thief_2", "Images/Image 867.png");
	LoadImg("fairy_1", "Images/Image 870.png");
	LoadImg("fairy_2", "Images/Image 872.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 33;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);


	LoadImg("slashb1", "Images/Image 927.png");
	LoadImg("slashb2", "Images/Image 930.png");
	LoadImg("slashb3", "Images/Image 932.png");
	LoadImg("slashb4", "Images/Image 934.png");
	LoadImg("slashb5", "Images/Image 936.png");
	LoadImg("slashb6", "Images/Image 938.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 35;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("explode1", "Images/Image 1016.png");
	LoadImg("explode2", "Images/Image 1020.png");
	LoadImg("explode3", "Images/Image 1022.png");
	LoadImg("explode4", "Images/Image 1024.png");

	LoadImg("fist1", "Images/Image 1063.png");
	LoadImg("fist2", "Images/Image 1066.png");
	LoadImg("fist3", "Images/Image 1068.png");
	LoadImg("fist4", "Images/Image 1070.png");
	LoadImg("fist5", "Images/Image 1072.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 38;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fistb1", "Images/Image 905.png");
	LoadImg("fistb2", "Images/Image 908.png");
	LoadImg("fistb3", "Images/Image 910.png");
	LoadImg("fistb4", "Images/Image 912.png");
	LoadImg("fistb5", "Images/Image 914.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 40;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("suck1", "Images/Image 1074.png");
	LoadImg("suck2", "Images/Image 1077.png");
	LoadImg("suck3", "Images/Image 1079.png");
	LoadImg("suck4", "Images/Image 1081.png");
	LoadImg("suck5", "Images/Image 1083.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 41;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("suckb1", "Images/Image 916.png");
	LoadImg("suckb2", "Images/Image 919.png");
	LoadImg("suckb3", "Images/Image 921.png");
	LoadImg("suckb4", "Images/Image 923.png");
	LoadImg("suckb5", "Images/Image 925.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 43;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("slash1", "Images/Image 1086.png");
	LoadImg("slash2", "Images/Image 1089.png");
	LoadImg("slash3", "Images/Image 1091.png");
	LoadImg("slash4", "Images/Image 1093.png");
	LoadImg("slash5", "Images/Image 1095.png");
	LoadImg("slash6", "Images/Image 1097.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 45;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	//LoadImg("sword1", "Images/Image 1086.png");
	//LoadImg("sword2", "Images/Image 1089.png");
	//LoadImg("sword3", "Images/Image 1091.png");
	//LoadImg("sword4", "Images/Image 1093.png");
	//LoadImg("sword5", "Images/Image 1095.png");
	//LoadImg("sword6", "Images/Image 1097.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 46;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("poision1", "Images/Image 1102.png");
	LoadImg("poision2", "Images/Image 1104.png");
	LoadImg("poision3", "Images/Image 1106.png");
	LoadImg("poision4", "Images/Image 1108.png");
	LoadImg("poision5", "Images/Image 1110.png");

	LoadImg("flash1", "Images/Image 1112.png");
	LoadImg("flash2", "Images/Image 1115.png");
	LoadImg("flash3", "Images/Image 1117.png");
	LoadImg("flash4", "Images/Image 1119.png");
	LoadImg("flash5", "Images/Image 1121.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 51;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("water1", "Images/Image 1123.png");
	LoadImg("water2", "Images/Image 1126.png");
	LoadImg("water3", "Images/Image 1128.png");
	LoadImg("water4", "Images/Image 1130.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent =54;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("greenlaser1", "Images/Image 1132.png");
	LoadImg("greenlaser2", "Images/Image 1135.png");
	LoadImg("greenlaser3", "Images/Image 1137.png");
	LoadImg("greenlaser4", "Images/Image 1139.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 56;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("nuclear1", "Images/Image 1141.png");
	LoadImg("nuclear2", "Images/Image 1144.png");
	LoadImg("nuclear3", "Images/Image 1146.png");
	LoadImg("nuclear4", "Images/Image 1148.png");
	LoadImg("nuclear5", "Images/Image 1150.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 57;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("laser1", "Images/Image 1163.png");
	LoadImg("laser2", "Images/Image 1166.png");
	LoadImg("laser3", "Images/Image 1168.png");
	LoadImg("laser4", "Images/Image 1170.png");

	LoadImg("magic1", "Images/Image 1152.png");
	LoadImg("magic2", "Images/Image 1155.png");
	LoadImg("magic3", "Images/Image 1157.png");
	LoadImg("magic4", "Images/Image 1159.png");
	LoadImg("magic5", "Images/Image 1161.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 60;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fireb1", "Images/Image 10020.png");
	LoadImg("fireb2", "Images/Image 10021.png");
	LoadImg("fireb3", "Images/Image 10022.png");
	LoadImg("fireb4", "Images/Image 10023.png");
	LoadImg("fireb5", "Images/Image 10024.png");
	LoadImg("fireb6", "Images/Image 10025.png");
	LoadImg("fireb7", "Images/Image 10026.png");
	LoadImg("fireb8", "Images/Image 10027.png");
	LoadImg("fireb9", "Images/Image 10028.png");
	LoadImg("fireb10", "Images/Image 10029.png");
	LoadImg("fireb11", "Images/Image 10030.png");
	LoadImg("fireb12", "Images/Image 10031.png");
	LoadImg("fireb13", "Images/Image 10032.png");
	LoadImg("fireb14", "Images/Image 10033.png");
	LoadImg("fireb15", "Images/Image 10034.png");
	LoadImg("fireb16", "Images/Image 10035.png");
	LoadImg("fireb17", "Images/Image 10036.png");
	LoadImg("fireb18", "Images/Image 10037.png");
	LoadImg("fireb19", "Images/Image 10038.png");
	LoadImg("fireb20", "Images/Image 10039.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 63;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fireswordb1", "Images/Image 1294.png");
	LoadImg("fireswordb2", "Images/Image 1295.png");
	LoadImg("fireswordb3", "Images/Image 1296.png");
	LoadImg("fireswordb4", "Images/Image 1297.png");
	LoadImg("fireswordb5", "Images/Image 1298.png");

	LoadImg("ice1", "Images/Image 1336.png");
	LoadImg("ice2", "Images/Image 1337.png");
	LoadImg("ice3", "Images/Image 1338.png");
	LoadImg("ice4", "Images/Image 1339.png");
	LoadImg("ice5", "Images/Image 1340.png");
	LoadImg("ice6", "Images/Image 1341.png");
	LoadImg("ice7", "Images/Image 1342.png");
	LoadImg("ice8", "Images/Image 1343.png");
	LoadImg("ice9", "Images/Image 1344.png");
	LoadImg("ice10", "Images/Image 1345.png");
	LoadImg("ice11", "Images/Image 1346.png");
	LoadImg("ice12", "Images/Image 1347.png");
	LoadImg("ice13", "Images/Image 1348.png");

	LoadImg("iceb1", "Images/Image 1288.png");
	LoadImg("iceb2", "Images/Image 1289.png");
	LoadImg("iceb3", "Images/Image 1290.png");
	LoadImg("iceb4", "Images/Image 1291.png");
	LoadImg("iceb5", "Images/Image 1292.png");
	LoadImg("iceb6", "Images/Image 1293.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 67;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("curseb1", "Images/Image 1299.png");
	LoadImg("curseb2", "Images/Image 1300.png");
	LoadImg("curseb3", "Images/Image 1301.png");
	LoadImg("curseb4", "Images/Image 1302.png");
	LoadImg("curseb5", "Images/Image 1303.png");
	LoadImg("curseb6", "Images/Image 1304.png");
	LoadImg("curseb7", "Images/Image 1305.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 69;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("curse1", "Images/Image 1306.png");
	LoadImg("curse2", "Images/Image 1307.png");
	LoadImg("curse3", "Images/Image 1308.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 71;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("barrageb1", "Images/Image 1330.png");
	LoadImg("barrageb2", "Images/Image 1331.png");
	LoadImg("barrageb3", "Images/Image 1332.png");
	LoadImg("barrageb4", "Images/Image 1333.png");
	LoadImg("barrageb5", "Images/Image 1334.png");
	LoadImg("barrageb6", "Images/Image 1335.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 73;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fire1", "Images/Image 10001.png");
	LoadImg("fire2", "Images/Image 10002.png");
	LoadImg("fire3", "Images/Image 10003.png");
	LoadImg("fire4", "Images/Image 10004.png");
	LoadImg("fire5", "Images/Image 10005.png");
	LoadImg("fire6", "Images/Image 10006.png");
	LoadImg("fire7", "Images/Image 10007.png");
	LoadImg("fire8", "Images/Image 10008.png");
	LoadImg("fire9", "Images/Image 10009.png");
	LoadImg("fire10", "Images/Image 10010.png");
	LoadImg("fire11", "Images/Image 10011.png");
	LoadImg("fire12", "Images/Image 10012.png");
	LoadImg("fire13", "Images/Image 10013.png");
	LoadImg("fire14", "Images/Image 10014.png");
	LoadImg("fire15", "Images/Image 10015.png");
	LoadImg("fire16", "Images/Image 10016.png");
	LoadImg("fire17", "Images/Image 10017.png");
	LoadImg("fire18", "Images/Image 10018.png");
	LoadImg("fire19", "Images/Image 10019.png");

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 75;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("barrage1", "Images/Image 10041.png");
	LoadImg("barrage2", "Images/Image 10042.png");
	LoadImg("barrage3", "Images/Image 10043.png");
	LoadImg("barrage4", "Images/Image 10044.png");
	LoadImg("barrage5", "Images/Image 10045.png");
	LoadImg("barrage6", "Images/Image 10046.png");
	LoadImg("barrage7", "Images/Image 10047.png");
	LoadImg("barrage8", "Images/Image 10048.png");
	LoadImg("barrage9", "Images/Image 10049.png");
	LoadImg("barrage10", "Images/Image 10050.png");
	LoadImg("barrage11", "Images/Image 10051.png");
	LoadImg("barrage12", "Images/Image 10052.png");
	LoadImg("barrage13", "Images/Image 10053.png");
	LoadImg("barrage14", "Images/Image 10054.png");
	LoadImg("barrage15", "Images/Image 10055.png");
	LoadImg("barrage16", "Images/Image 10056.png");
	LoadImg("barrage17", "Images/Image 10057.png");
	LoadImg("barrage18", "Images/Image 10058.png");
	LoadImg("barrage19", "Images/Image 10059.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 77;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fog1", "Images/Image 1349.png");
	LoadImg("fog2", "Images/Image 1350.png");
	LoadImg("fog3", "Images/Image 1351.png");
	LoadImg("fog4", "Images/Image 1352.png");
	LoadImg("fog5", "Images/Image 1353.png");
	LoadImg("fog6", "Images/Image 1354.png");
	LoadImg("fog7", "Images/Image 1355.png");
	LoadImg("fog8", "Images/Image 1356.png");
	LoadImg("fog9", "Images/Image 1357.png");
	LoadImg("fog10", "Images/Image 1358.png");
	LoadImg("fog11", "Images/Image 1359.png");
	LoadImg("fog12", "Images/Image 1360.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 79;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("fogb1", "Images/Image 1361.png");
	LoadImg("fogb2", "Images/Image 1362.png");
	LoadImg("fogb3", "Images/Image 1363.png");
	LoadImg("fogb4", "Images/Image 1364.png");
	LoadImg("fogb5", "Images/Image 1365.png");
	LoadImg("fogb6", "Images/Image 1366.png");
	LoadImg("fogb7", "Images/Image 1367.png");
	LoadImg("fogb8", "Images/Image 1368.png");
	LoadImg("fogb9", "Images/Image 1369.png");
	LoadImg("fogb10", "Images/Image 1370.png");
	LoadImg("fogb11", "Images/Image 1371.png");
	LoadImg("fogb12", "Images/Image 1372.png");
	LoadImg("fogb13", "Images/Image 1373.png");
	LoadImg("fogb14", "Images/Image 1374.png");
	LoadImg("fogb15", "Images/Image 1375.png");
	LoadImg("fogb16", "Images/Image 1376.png");
	LoadImg("fogb17", "Images/Image 1377.png");
	LoadImg("fogb18", "Images/Image 1378.png");
	LoadImg("fogb19", "Images/Image 1379.png");
	LoadImg("fogb20", "Images/Image 1380.png");
	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 81;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	LoadImg("waterb1", "Images/Image 967.png");
	LoadImg("waterb2", "Images/Image 970.png");
	LoadImg("waterb3", "Images/Image 972.png");
	LoadImg("waterb4", "Images/Image 974.png");

	LoadImg("explodeb1", "Images/Image 985.png");
	LoadImg("explodeb2", "Images/Image 988.png");
	LoadImg("explodeb3", "Images/Image 990.png");
	LoadImg("explodeb4", "Images/Image 992.png");
	LoadImg("explodeb5", "Images/Image 994.png");

	LoadImg("magicb1", "Images/Image 996.png");
	LoadImg("magicb2", "Images/Image 996.png");
	LoadImg("magicb3", "Images/Image 1001.png");
	LoadImg("magicb4", "Images/Image 1003.png");
	LoadImg("magicb5", "Images/Image 1005.png");


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 90;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	m_mD2DGif.insert(pair<string, CD2DGif>("opendoor1", d2dGifBuf));
	m_mD2DGif["opendoor1"].AddImage(m_mD2DImage["door1"], Vector(67, 64));
	m_mD2DGif["opendoor1"].AddImage(m_mD2DImage["door12"], Vector(67, 64));
	m_mD2DGif["opendoor1"].AddImage(m_mD2DImage["door13"], Vector(67, 64));
	m_mD2DGif["opendoor1"].AddImage(m_mD2DImage["door14"], Vector(67, 64));
	m_mD2DGif["opendoor1"].AddImage(m_mD2DImage["door15"], Vector(67, 64));

	m_mD2DGif.insert(pair<string, CD2DGif>("opendoor2", d2dGifBuf));
	m_mD2DGif["opendoor2"].AddImage(m_mD2DImage["door2"], Vector(67, 64));
	m_mD2DGif["opendoor2"].AddImage(m_mD2DImage["door22"], Vector(67, 64));
	m_mD2DGif["opendoor2"].AddImage(m_mD2DImage["door23"], Vector(67, 64));
	m_mD2DGif["opendoor2"].AddImage(m_mD2DImage["door24"], Vector(67, 64));
	m_mD2DGif["opendoor2"].AddImage(m_mD2DImage["door25"], Vector(67, 64));

	m_mD2DGif.insert(pair<string, CD2DGif>("opendoor3", d2dGifBuf));
	m_mD2DGif["opendoor3"].AddImage(m_mD2DImage["door3"], Vector(67, 64));
	m_mD2DGif["opendoor3"].AddImage(m_mD2DImage["door32"], Vector(67, 64));
	m_mD2DGif["opendoor3"].AddImage(m_mD2DImage["door33"], Vector(67, 64));
	m_mD2DGif["opendoor3"].AddImage(m_mD2DImage["door34"], Vector(67, 64));
	m_mD2DGif["opendoor3"].AddImage(m_mD2DImage["door35"], Vector(67, 64));

	m_mD2DGif.insert(pair<string, CD2DGif>("openjail", d2dGifBuf));
	m_mD2DGif["openjail"].AddImage(m_mD2DImage["jail"], Vector(67, 64));
	m_mD2DGif["openjail"].AddImage(m_mD2DImage["jail2"], Vector(67, 64));
	m_mD2DGif["openjail"].AddImage(m_mD2DImage["jail3"], Vector(67, 64));
	m_mD2DGif["openjail"].AddImage(m_mD2DImage["jail4"], Vector(67, 64));
	m_mD2DGif["openjail"].AddImage(m_mD2DImage["jail5"], Vector(67, 64));


	m_mD2DGif.insert(pair<string, CD2DGif>("heroslashb", d2dBattleBuf));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb1"],Vector(67,64));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb2"], Vector(67, 64));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb3"], Vector(67, 64));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb4"], Vector(67, 64));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb5"], Vector(67, 64));
	m_mD2DGif["heroslashb"].AddImage(m_mD2DImage["slashb6"], Vector(67, 64));


	m_mD2DGif.insert(pair<string, CD2DGif>("heroslash", d2dBattleBuf));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash1"], Vector(55, 50));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash2"], Vector(55, 50));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash3"], Vector(55, 50));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash4"], Vector(55, 50));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash5"], Vector(55, 50));
	m_mD2DGif["heroslash"].AddImage(m_mD2DImage["slash6"], Vector(55, 50));


	m_mD2DGif.insert(pair<string, CD2DGif>("fist", d2dBattleBuf));
	m_mD2DGif["fist"].AddImage(m_mD2DImage["fist1"], Vector(55, 50));
	m_mD2DGif["fist"].AddImage(m_mD2DImage["fist2"], Vector(55, 50));
	m_mD2DGif["fist"].AddImage(m_mD2DImage["fist3"], Vector(55, 50));
	m_mD2DGif["fist"].AddImage(m_mD2DImage["fist4"], Vector(55, 50));
	m_mD2DGif["fist"].AddImage(m_mD2DImage["fist5"], Vector(55, 50));

	m_mD2DGif["fistb"].AddImage(m_mD2DImage["fistb1"], Vector(68, 60));
	m_mD2DGif["fistb"].AddImage(m_mD2DImage["fistb2"], Vector(68, 60));
	m_mD2DGif["fistb"].AddImage(m_mD2DImage["fistb3"], Vector(84, 69));
	m_mD2DGif["fistb"].AddImage(m_mD2DImage["fistb4"], Vector(84, 69));
	m_mD2DGif["fistb"].AddImage(m_mD2DImage["fistb5"], Vector(84, 69));


	m_mD2DGif.insert(pair<string, CD2DGif>("water", d2dBattleBuf));
	m_mD2DGif["water"].AddImage(m_mD2DImage["water1"], Vector(64, 61));
	m_mD2DGif["water"].AddImage(m_mD2DImage["water2"], Vector(64, 61));
	m_mD2DGif["water"].AddImage(m_mD2DImage["water3"], Vector(64, 61));
	m_mD2DGif["water"].AddImage(m_mD2DImage["water4"], Vector(64, 61));

	m_mD2DGif.insert(pair<string, CD2DGif>("sword", d2dBattleBuf));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash1"], Vector(55, 50));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash2"], Vector(55, 50));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash3"], Vector(55, 50));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash4"], Vector(55, 50));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash5"], Vector(55, 50));
	m_mD2DGif["sword"].AddImage(m_mD2DImage["slash6"], Vector(55, 50));


	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb1"], Vector(67, 64));
	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb2"], Vector(67, 64));
	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb3"], Vector(67, 64));
	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb4"], Vector(67, 64));
	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb5"], Vector(67, 64));
	m_mD2DGif["swordb"].AddImage(m_mD2DImage["slashb6"], Vector(67, 64));


	//m_mBlock.insert(pair<string, char>("wall", (char)255));
	m_mD2DGif.insert(pair<string, CD2DGif>("suck", d2dBattleBuf));
	m_mD2DGif["suck"].AddImage(m_mD2DImage["suck1"], Vector(49, 47));
	m_mD2DGif["suck"].AddImage(m_mD2DImage["suck2"], Vector(49, 47));
	m_mD2DGif["suck"].AddImage(m_mD2DImage["suck3"], Vector(49, 47));
	m_mD2DGif["suck"].AddImage(m_mD2DImage["suck4"], Vector(49, 47));
	m_mD2DGif["suck"].AddImage(m_mD2DImage["suck5"], Vector(49, 47));

	m_mD2DGif["suckb"].AddImage(m_mD2DImage["suck1"], Vector(94, 75));
	m_mD2DGif["suckb"].AddImage(m_mD2DImage["suck2"], Vector(94, 75));
	m_mD2DGif["suckb"].AddImage(m_mD2DImage["suck3"], Vector(94, 75));
	m_mD2DGif["suckb"].AddImage(m_mD2DImage["suck4"], Vector(94, 75));
	m_mD2DGif["suckb"].AddImage(m_mD2DImage["suck5"], Vector(94, 75));


	m_mD2DGif.insert(pair<string, CD2DGif>("flash", d2dBattleBuf));
	m_mD2DGif["flash"].AddImage(m_mD2DImage["flash1"], Vector(55, 54));
	m_mD2DGif["flash"].AddImage(m_mD2DImage["flash2"], Vector(55, 54));
	m_mD2DGif["flash"].AddImage(m_mD2DImage["flash3"], Vector(55, 54));
	m_mD2DGif["flash"].AddImage(m_mD2DImage["flash4"], Vector(55, 54));
	m_mD2DGif["flash"].AddImage(m_mD2DImage["flash5"], Vector(55, 54));


	m_mD2DGif.insert(pair<string, CD2DGif>("explode", d2dBattleBuf));
	m_mD2DGif["explode"].AddImage(m_mD2DImage["explode1"], Vector(66, 68));
	m_mD2DGif["explode"].AddImage(m_mD2DImage["explode2"], Vector(66, 68));
	m_mD2DGif["explode"].AddImage(m_mD2DImage["explode3"], Vector(66, 68));
	m_mD2DGif["explode"].AddImage(m_mD2DImage["explode4"], Vector(66, 68));

	m_mD2DGif.insert(pair<string, CD2DGif>("nuclear", d2dBattleBuf));
	m_mD2DGif["nuclear"].AddImage(m_mD2DImage["nuclear1"], Vector(80, 44));
	m_mD2DGif["nuclear"].AddImage(m_mD2DImage["nuclear2"], Vector(80, 44));
	m_mD2DGif["nuclear"].AddImage(m_mD2DImage["nuclear3"], Vector(80, 44));
	m_mD2DGif["nuclear"].AddImage(m_mD2DImage["nuclear4"], Vector(80, 44));
	m_mD2DGif["nuclear"].AddImage(m_mD2DImage["nuclear5"], Vector(80, 44));

	m_mD2DGif.insert(pair<string, CD2DGif>("poision", d2dBattleBuf));
	m_mD2DGif["poision"].AddImage(m_mD2DImage["poision1"], Vector(39, 69));
	m_mD2DGif["poision"].AddImage(m_mD2DImage["poision2"], Vector(39, 69));
	m_mD2DGif["poision"].AddImage(m_mD2DImage["poision3"], Vector(39, 69));
	m_mD2DGif["poision"].AddImage(m_mD2DImage["poision4"], Vector(39, 69));
	m_mD2DGif["poision"].AddImage(m_mD2DImage["poision5"], Vector(39, 69));

	m_mD2DGif.insert(pair<string, CD2DGif>("greenlaser", d2dBattleBuf));
	m_mD2DGif["greenlaser"].AddImage(m_mD2DImage["greenlaser1"], Vector(44, 61));
	m_mD2DGif["greenlaser"].AddImage(m_mD2DImage["greenlaser2"], Vector(44, 61));
	m_mD2DGif["greenlaser"].AddImage(m_mD2DImage["greenlaser3"], Vector(44, 61));
	m_mD2DGif["greenlaser"].AddImage(m_mD2DImage["greenlaser4"], Vector(44, 61));


	m_mD2DGif.insert(pair<string, CD2DGif>("laser", d2dBattleBuf));
	m_mD2DGif["laser"].AddImage(m_mD2DImage["laser1"], Vector(44, 61));
	m_mD2DGif["laser"].AddImage(m_mD2DImage["laser2"], Vector(44, 61));
	m_mD2DGif["laser"].AddImage(m_mD2DImage["laser3"], Vector(44, 61));
	m_mD2DGif["laser"].AddImage(m_mD2DImage["laser4"], Vector(44, 61));


	m_mD2DGif["magic"].AddImage(m_mD2DImage["magic1"], Vector(38, 40));
	m_mD2DGif["magic"].AddImage(m_mD2DImage["magic2"], Vector(38, 40));
	m_mD2DGif["magic"].AddImage(m_mD2DImage["magic3"], Vector(38, 40));
	m_mD2DGif["magic"].AddImage(m_mD2DImage["magic4"], Vector(38, 40));
	m_mD2DGif["magic"].AddImage(m_mD2DImage["magic5"], Vector(38, 40));

	m_mD2DGif["firesword"] = m_mD2DGif["sword"];

	m_mD2DGif["fireswordb"].AddImage(m_mD2DImage["fireswordb1"], Vector(600, 600));
	m_mD2DGif["fireswordb"].AddImage(m_mD2DImage["fireswordb2"], Vector(600, 600));
	m_mD2DGif["fireswordb"].AddImage(m_mD2DImage["fireswordb3"], Vector(600, 600));
	m_mD2DGif["fireswordb"].AddImage(m_mD2DImage["fireswordb4"], Vector(600, 600));
	m_mD2DGif["fireswordb"].AddImage(m_mD2DImage["fireswordb5"], Vector(600, 600));


	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire1"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire2"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire3"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire4"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire5"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire6"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire7"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire8"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire9"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire10"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire11"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire12"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire13"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire14"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire15"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire16"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire17"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire18"], Vector(600, 600));
	m_mD2DGif["fire"].AddImage(m_mD2DImage["fire19"], Vector(600, 600));
	m_mD2DGif["fire"].SetFPS(50);

	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb1"], Vector(512,512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb2"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb3"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb4"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb5"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb6"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb7"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb8"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb9"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb10"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb11"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb12"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb13"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb14"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb15"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb16"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb17"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb18"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb19"], Vector(512, 512));
	m_mD2DGif["fireb"].AddImage(m_mD2DImage["fireb20"], Vector(512, 512));
	m_mD2DGif["fireb"].SetFPS(50);

	//m_mD2DGif["ice"].AddImage(m_mD2DImage["ice1"], Vector(55, 50));

	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice1"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice2"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice3"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice4"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice5"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice6"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice7"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice8"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice9"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice10"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice11"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice12"], Vector(800, 600));
	m_mD2DGif["ice"].AddImage(m_mD2DImage["ice13"], Vector(800, 600));
	m_mD2DGif["ice"].SetFPS(50);
	

	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb1"], Vector(1024, 1024));
	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb2"], Vector(1024, 1024));
	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb3"], Vector(1024, 1024));
	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb4"], Vector(1024, 1024));
	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb5"], Vector(1024, 1024));
	m_mD2DGif["iceb"].AddImage(m_mD2DImage["iceb6"], Vector(1024, 1024));


	m_mD2DGif["curse"].AddImage(m_mD2DImage["curse1"], Vector(700, 700));
	m_mD2DGif["curse"].AddImage(m_mD2DImage["curse2"], Vector(700, 700));
	m_mD2DGif["curse"].AddImage(m_mD2DImage["curse3"], Vector(700, 700));

	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage1"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage2"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage3"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage4"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage5"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage6"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage7"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage8"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage9"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage10"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage11"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage12"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage13"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage14"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage15"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage16"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage17"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage18"], Vector(600, 600));
	m_mD2DGif["barrage"].AddImage(m_mD2DImage["barrage19"], Vector(600, 600));
	m_mD2DGif["barrage"].SetFPS(50);

	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb1"], Vector(700, 700));
	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb2"], Vector(700, 700));
	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb3"], Vector(700, 700));
	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb4"], Vector(700, 700));
	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb5"], Vector(700, 700));
	m_mD2DGif["barrageb"].AddImage(m_mD2DImage["barrageb6"], Vector(700, 700));


	m_mD2DGif["hit"].AddImage(m_mD2DImage["blank"], Vector(20, 20));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["blank"], Vector(20, 20));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["blank"], Vector(20, 20));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["blank"], Vector(20, 20));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb1"], Vector(700, 700));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb2"], Vector(700, 700));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb3"], Vector(700, 700));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb4"], Vector(700, 700));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb5"], Vector(700, 700));
	m_mD2DGif["hit"].AddImage(m_mD2DImage["barrageb6"], Vector(700, 700));

	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb1"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb2"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb3"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb4"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb5"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb6"], Vector(700, 700));
	m_mD2DGif["curseb"].AddImage(m_mD2DImage["curseb7"], Vector(700, 700));

	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog1"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog2"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog3"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog4"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog5"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog6"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog7"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog8"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog9"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog10"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog11"], Vector(640, 640));
	m_mD2DGif["fog"].AddImage(m_mD2DImage["fog12"], Vector(640, 640));
	m_mD2DGif["fog"].SetFPS(50);



	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb1"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb2"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb3"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb4"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb5"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb6"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb7"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb8"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb9"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb10"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb11"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb12"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb13"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb14"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb15"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb16"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb17"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb18"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb19"], Vector(900, 900));
	m_mD2DGif["fogb"].AddImage(m_mD2DImage["fogb20"], Vector(900, 900));
	m_mD2DGif["fogb"].SetFPS(50);

	m_mD2DGif["waterb"].AddImage(m_mD2DImage["waterb1"], Vector(47, 74));
	m_mD2DGif["waterb"].AddImage(m_mD2DImage["waterb2"], Vector(47, 74));
	m_mD2DGif["waterb"].AddImage(m_mD2DImage["waterb3"], Vector(47, 74));
	m_mD2DGif["waterb"].AddImage(m_mD2DImage["waterb4"], Vector(47, 74));

	m_mD2DGif["explodeb"].AddImage(m_mD2DImage["explodeb1"], Vector(49, 61));
	m_mD2DGif["explodeb"].AddImage(m_mD2DImage["explodeb2"], Vector(49, 61));
	m_mD2DGif["explodeb"].AddImage(m_mD2DImage["explodeb3"], Vector(49, 61));
	m_mD2DGif["explodeb"].AddImage(m_mD2DImage["explodeb4"], Vector(49, 61));
	m_mD2DGif["explodeb"].AddImage(m_mD2DImage["explodeb5"], Vector(49, 61));

	m_mD2DGif["nuclearb"].AddImage(m_mD2DImage["explodeb1"], Vector(49, 61));
	m_mD2DGif["nuclearb"].AddImage(m_mD2DImage["explodeb2"], Vector(49, 61));
	m_mD2DGif["nuclearb"].AddImage(m_mD2DImage["explodeb3"], Vector(49, 61));
	m_mD2DGif["nuclearb"].AddImage(m_mD2DImage["explodeb4"], Vector(49, 61));
	m_mD2DGif["nuclearb"].AddImage(m_mD2DImage["explodeb5"], Vector(49, 61));

	m_mD2DGif["magicb"].AddImage(m_mD2DImage["magicb1"], Vector(49, 61));
	m_mD2DGif["magicb"].AddImage(m_mD2DImage["magicb2"], Vector(49, 61));
	m_mD2DGif["magicb"].AddImage(m_mD2DImage["magicb3"], Vector(49, 61));
	m_mD2DGif["magicb"].AddImage(m_mD2DImage["magicb4"], Vector(49, 61));
	m_mD2DGif["magicb"].AddImage(m_mD2DImage["magicb5"], Vector(49, 61));


	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 93;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	//d2dImage.push_back(d2dImageBuf);
	//d2dImage[d2dImage.size()-1].LoadImageFromFile(D2DC.pRenderTarget(), L"Images/Image 27.png");



	///////////////
	//	���ع���
	///////////////
	if (!LoadMonster())return false;
	///////////////
	//
	///////////////

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 95;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);

	///////////////
	//	��������
	/////////////

	Sound.SetSoundFilePath(L"./wav/");

	Sound.LoadSound(L"Sound 272.wav");
	Sound.LoadSound(L"Sound 564.wav");
	Sound.LoadSound(L"Sound 1350.wav");
	Sound.LoadSound(L"Sound 1375.wav");
	Sound.LoadSound(L"Sound 1615.wav");
	Sound.LoadSound(L"Sound 1617.wav");
	Sound.LoadSound(L"Sound 1618.wav");

	Sound.LoadSound("miss", L"Sound 1041.wav");

	Sound.LoadSound("sword", L"Sound 1088.wav");
	Sound.LoadSound("swordb", L"Sound 929.wav");
	Sound.LoadSound("fist", L"Sound 1065.wav");
	Sound.LoadSound("fistb", L"Sound 907.wav");
	Sound.LoadSound("suck", L"Sound 1076.wav");
	Sound.LoadSound("suckb", L"Sound 918.wav");

	Sound.LoadSound("water", L"Sound 1125.wav");
	Sound.LoadSound("waterb", L"Sound 969.wav");
	Sound.LoadSound("flash", L"Sound 1114.wav");
	Sound.LoadSound("flashb", L"Sound 958.wav");
	Sound.LoadSound("greenlaser", L"Sound 1134.wav");
	Sound.LoadSound("greenlaserb", L"Sound 978.wav");

	Sound.LoadSound("laser", L"Sound 1165.wav");
	Sound.LoadSound("laserb", L"Sound 1009.wav");

	Sound.LoadSound("explode", L"Sound 1172.wav");
	Sound.LoadSound("explodeb", L"Sound 998.wav");
	Sound.LoadSound("nuclear", L"Sound 1143.wav");
	Sound.LoadSound("nuclearb", L"Sound 987.wav");

	Sound.LoadSound("poision", L"Sound 1101.wav");
	Sound.LoadSound("poisionb", L"Sound 942.wav");

	Sound.LoadSound("magic", L"Sound 1154.wav");
	Sound.LoadSound("magicb", L"Sound 998.wav");

	Sound.LoadSound("fire", L"fire.wav");
	Sound.LoadSound("fireb", L"fireb.wav");
	Sound.LoadSound("firesword", L"firesword.wav");
	Sound.LoadSound("fireswordb", L"fireswordb.wav");
	Sound.LoadSound("ice", L"ice.wav");
	Sound.LoadSound("iceb", L"iceb.wav");
	Sound.LoadSound("curse", L"curse.wav");
	Sound.LoadSound("curseb", L"curseb.wav");
	Sound.LoadSound("barrage", L"barrage.wav");
	Sound.LoadSound("barrageb", L"barrageb.wav");
	Sound.LoadSound("fog", L"fog.wav");
	Sound.LoadSound("fogb", L"fogb.wav");
	////////////////
	//
	////////////////

	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 98;
	Sleep(LOADING_DELAY);
	WaitForSingleObject(RenderMutex, INFINITE);
	////////////////
	// ���ص�ͼ
	///////////////
	if (!LoadMap())return false;
	///////////////
	//
	///////////////
	ReleaseSemaphore(RenderMutex, 1, NULL);
	nLoadPercent = 100;
	WaitForSingleObject(RenderMutex, INFINITE);

	return true;
}

/////////////////////////
//
//
//     ���ص�ͼ
//
//
/////////////////////////
bool	CGame::LoadMap(){


	Floor fBuff;
	//char MapBuf[Map_Width][Map_Width] ;
	m_map.push_back(fBuff);//0��ȥ����

	char cBuff[25];
	WCHAR wBuff[MAX_PATH];
	WCHAR numBuff[15];

	for (int i = 1; i <= MAX_FLOOR; i++){
		_tcscpy_s(wBuff, L"./data/");
		_itot_s(i, numBuff, 10);
		_tcscat_s(wBuff, numBuff);
		_tcscat_s(wBuff, L".map");

		File.ReadBinary(wBuff, (LPSTR)cBuff, 2);
		//fseek(fp, 2, SEEK_SET);
		File.ReadBinary(wBuff, (LPSTR)fBuff.Block, Map_Width*Map_Width, 1, 2);

		m_map.push_back(fBuff);
	}
	//m_map.insert(m_map.begin(),MapBuf);

	return true;
}


#define LoadImgM(alias,path)  	m_mD2DImage.insert(pair<string, CD2DImage>(alias, d2dImageBuf));m_mD2DImage[alias].LoadImageFromFile(D2DC.pRenderTarget(), path);


bool	CGame::LoadMonster(){

	char cBuff[40];
	WCHAR wBuff[20];
	Monster mBuff;

	WCHAR pathBuff[MAX_PATH] = {0};

	CD2DImage d2dImageBuf;




	for (int i = 1; i <= MONSTER_COUNT; i++){
		sprintf_s(cBuff, "Monster%d", i);
		_stprintf_s(wBuff, L"Monster%d", i);

		mBuff.IDString = cBuff;
		mBuff.Name= File.ReadString(wBuff,L"Name",L"",L"./data/monster.dat");
		pathBuff[_tcslen(pathBuff)] = L'\0';
		mBuff.Image1 = File.ReadString(wBuff, L"Image1", L"Image 27.png", L"./data/monster.dat");
		mBuff.Image2 =File.ReadString(wBuff, L"Image2", L"Image 27.png", L"./data/monster.dat");
		mBuff.Weapon = File.ReadStringA(cBuff, "Weapon", "fist", "./data/monster.dat");
		mBuff.HP=File.ReadInt(wBuff, L"HP", 0, L"./data/monster.dat");
		mBuff.Attack=File.ReadInt(wBuff, L"Attack", 0, L"./data/monster.dat");
		mBuff.Defend= File.ReadInt(wBuff, L"Defend", 0, L"./data/monster.dat");
		mBuff.Swift= File.ReadInt(wBuff, L"Swift", 0, L"./data/monster.dat");
		mBuff.Combo= File.ReadInt(wBuff, L"Combo", 0, L"./data/monster.dat");
		mBuff.Ability = File.ReadString(wBuff, L"Ability", L"", L"./data/monster.dat");
		mBuff.Hemophagia= File.ReadInt(wBuff, L"Hemophagia", 0, L"./data/monster.dat");
		mBuff.Critical= File.ReadInt(wBuff, L"Critical", 0, L"./data/monster.dat");
		mBuff.CriticalRatio= File.ReadInt(wBuff, L"CriticalRatio", 0, L"./data/monster.dat");
		mBuff.Exp=File.ReadInt(wBuff, L"Exp", 0, L"./data/monster.dat");
		mBuff.Gold= File.ReadInt(wBuff, L"Gold", 0, L"./data/monster.dat");


		strcpy_s(cBuff, mBuff.IDString.data());
		strcat_s(cBuff, "_1");
		
		CString csBuff = L"Images/";
		csBuff += mBuff.Image1;
		_tcscpy_s(pathBuff, L"Images/");
		_tcscat_s(pathBuff, mBuff.Image1);
		//_tcscat_l(pathBuff, (LPCTSTR)(mBuff.Image1));
		//pathBuff[mBuff.Image1.GetLength() + 7] = 0;
		//OutputDebugString(pathBuff);
		LoadImgM(cBuff, pathBuff);


		strcpy_s(cBuff, mBuff.IDString.data());
		strcat_s(cBuff, "_2");
		csBuff = L"Images/";
		_tcscpy_s(pathBuff, L"Images/");
		_tcscat_s(pathBuff, mBuff.Image2);
		//pathBuff[mBuff.Image2.GetLength()+7] = 0;
		//csBuff += mBuff.Image2;
		//OutputDebugString(pathBuff);
		LoadImgM(cBuff,pathBuff);


		m_mMonster.insert(pair<int,Monster>(i,mBuff));
	}

	return true;
}
//��ȡ��Ϸ����
bool	CGame::LoadConfig(){

	if (!File.isExist(L"./config.ini")) _ERROR(L"�Ҳ��������ļ�", true);
#ifdef MAP_LARGE
	m_gameConfig.SCREEN_WIDTH = File.ReadInt(L"Resolution14", L"Width", 1366, L"./config.ini");
	m_gameConfig.SCREEN_HEIGHT = File.ReadInt(TEXT("Resolution14"), TEXT("Height"), 768, TEXT("./config.ini"));
#else
	m_gameConfig.SCREEN_WIDTH = File.ReadInt(L"Resolution", L"Width", 1366, L"./config.ini");
	m_gameConfig.SCREEN_HEIGHT = File.ReadInt(TEXT("Resolution"), TEXT("Height"), 768, TEXT("./config.ini"));
#endif
	m_gameConfig.FULL_SCREEN = (File.ReadInt(TEXT("Resolution"), TEXT("FullScreen"), 0, TEXT("./config.ini"))!=0);
	m_gameConfig.HARDWARE_RENDER = (File.ReadInt(TEXT("Video"), TEXT("HardWareAcceleration"), 1, TEXT("./config.ini")) != 0);
	m_gameConfig.VERTICAL_SYNC = (File.ReadInt(TEXT("Video"), TEXT("VerticalSync"), 1, TEXT("./config.ini")) != 0);
	m_gameConfig.PERFORMANCE_PRIOR = (File.ReadInt(TEXT("Video"), TEXT("PerformancePrior"), 1, TEXT("./config.ini")) != 0);
	m_gameConfig.FPS = File.ReadInt(L"Video", L"Fps", 3, L"./config.ini");
//	Net.SetSendFrequency(File.ReadInt(TEXT("Net"), TEXT("SendFrequency"), 1, TEXT("./config.ini")));
	//Net.SetDelayMs(File.ReadInt(TEXT("Net"), TEXT("DelayMs"), 1, TEXT("./config.ini")));


	m_fUnitScale = fVector(m_gameConfig.SCREEN_WIDTH/(MAX_WIDTH_UNIT *1.0f),
		m_gameConfig.SCREEN_HEIGHT/(MAX_HEIGHT_UNIT*1.0f));//���±���

	return true;
}

#define BuffToType(value, type) value = *(type*)(cBuff + nBuffLength); nBuffLength += sizeof(type);
#define BuffToInt(value) BuffToType(value,int)
#define BuffToByte(value) BuffToType(value,BYTE)

bool CGame::LoadGame(int _which){

	char cBuff[14 * 14 * MAX_FLOOR + MAX_PLOT_STATE + 100 * sizeof(int)] = { 0 };
	WCHAR path[MAX_PATH];
	string str;
	int nBuffLength = 0;

	int nBuff[] = {
		Hero.GetFloor(),
		Hero.GetPosition().x,
		Hero.GetPosition().y,
		Hero.GetHP(),
		Hero.GetAttack(),
		Hero.GetDefense(),
		Hero.GetSwift(),
		Hero.GetCombo(),
		Hero.GetCritical(),
		Hero.GetCriticalRatio(),
		Hero.GetHemophagia(),
		Hero.GetLevel(),
		Hero.GetExp()
	};

	_stprintf(path, L"./sav/%d.sav", _which);

	File.ReadBinary(path, cBuff, MAX_FLOOR * Map_Width*Map_Width + sizeof(nBuff)+35*sizeof(int)+MAX_PLOT_STATE);

	for (int i = 1; i <= MAX_FLOOR; i++){
		for (int j = 0; j <= Map_Width - 1; j++){
			for (int k = 0; k <= Map_Width - 1; k++){
				m_map[i].Block[j][k] = cBuff[nBuffLength];
				nBuffLength++;
			}
		}
	}

	for (int i = 0; i < sizeof(nBuff) / sizeof(int); i++){
		BuffToInt(nBuff[i]);
	}

	Hero.LoadHero(nBuff);

	for (char i = (char)206; i <= (char)240; i++){
		BuffToInt(Hero.m_mItem[(char)i]);
	}

	for (int i = 0; i < MAX_PLOT_STATE; i++){
		BuffToByte(m_byPlotState[i]);
	}


	return true;
}

#define	AddToBuff(value,type) *(type*)(cBuff + nBuffLength) = value;nBuffLength += sizeof(type);
#define AddIntToBuff(value) AddToBuff(value,int)
#define AddByteToBuff(value) AddToBuff(value,BYTE)

bool CGame::SaveGame(int _which){

	char cBuff[14 * 14 * MAX_FLOOR + MAX_PLOT_STATE + 100*sizeof(int)] = {0};
	WCHAR path[MAX_PATH];
	string str;
	int nBuffLength=0;
	for (int i = 1; i <= MAX_FLOOR; i++){
		for (int j = 0; j <= Map_Width-1; j++){
			for (int k = 0; k<= Map_Width-1; k++){
				cBuff[nBuffLength] = m_map[i].Block[j][k];
				nBuffLength++;
			}
		}
	}	
	
	
	
	int nBuff[] = {
		Hero.GetFloor(),
		Hero.GetPosition().x,
		Hero.GetPosition().y,
		Hero.GetHP(),
		Hero.GetAttack(),
		Hero.GetDefense(),
		Hero.GetSwift(),
		Hero.GetCombo(),
		Hero.GetCritical(),
		Hero.GetCriticalRatio(),
		Hero.GetHemophagia(),
		Hero.GetLevel(),
		Hero.GetExp()
	};
	for (int i = 0; i < sizeof(nBuff) / sizeof(int); i++){
		AddIntToBuff(nBuff[i]);
	}



	for (char i = (char)206; i <= (char)240; i++){
		AddIntToBuff(Hero.m_mItem[(char)i]);
	}


	for (int i = 0; i < MAX_PLOT_STATE; i++){
		AddByteToBuff(m_byPlotState[i]);
	}

	_stprintf(path, L"./sav/%d.sav", _which);

	File.WriteBinary(path, cBuff, nBuffLength);




	return true;
}




//ȫ��ģʽ �����ֱ���
bool CGame::AdjustResolution(){

	if (m_gameConfig.FULL_SCREEN){
		Game.SetScreenResolution(m_gameConfig.SCREEN_WIDTH, m_gameConfig.SCREEN_HEIGHT);  //�ķֱ���
	}

	return true;
}


////////////////////////
//
//  ��Ϣ��������
//
////////////////////////
LRESULT CALLBACK CGame::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam){

	CString cstring;
	///////////////////////////////
	//����ʲô��Ϸ״̬�����Ĵ���
	//////////////////////////////
	switch (uMsg){

	case WM_KEYDOWN:
		m_KeyState[wParam] = KEYDOWN;
		switch (wParam){
		case VK_F8:
			m_ResolutionSetting.nResolutionNow++;
			if (m_ResolutionSetting.nResolutionNow >= m_ResolutionSetting.vResolution.size())m_ResolutionSetting.nResolutionNow = 0;
			MoveWindow(hWnd, 0, 0, m_ResolutionSetting.vResolution[m_ResolutionSetting.nResolutionNow].x,
				m_ResolutionSetting.vResolution[m_ResolutionSetting.nResolutionNow].y, true);
			break;
		}

	case WM_KEYUP:
		m_KeyState[wParam] = KEYUP;

		break;
	}

	/////////////////////////////
	//�ֲ�����Ϸ״̬�ֱ���д���
	/////////////////////////////
	switch (m_gameState)
	{
	//case GAME_MOTION:
		break;
	//case GAME_MAIN_MENU:
		//��ʾ��Ϣ
	case GAME_CAPTION:
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case VK_RETURN:
				m_gameState = GAME_STATE::GAME_RUNNING;
				break;
			}
		default:
			break;
		}
		break;
	case GAME_TIP://�Ի�
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case VK_RETURN:

				m_gameState = GAME_STATE::GAME_RUNNING;
				if(m_subState.bGiftReceiving) ReceiveGift();//̸�����˾��ж���û��������
				break;
			}

		default:
			break;
		}
		break;
		/////////////////
		//�鿴��������
		//////////////////
	case GAME_CHECK_MONSTER://
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case VK_LEFT:
				if (m_subState.sMonsterChecker.nPageNow > 1) {
					m_subState.sMonsterChecker.nPageNow--;
					Sound.Play(L"Sound 1618.wav", fTime());
				}
				break;
			case VK_RIGHT:
				if (m_subState.sMonsterChecker.nPageNow < m_subState.sMonsterChecker.nPageCount){
					m_subState.sMonsterChecker.nPageNow++;
					Sound.Play(L"Sound 1618.wav", fTime());
				}
				break;
			case VK_RETURN:
				m_gameState = GAME_STATE::GAME_RUNNING;
				break;
			}

		default:
			break;
		}
		break;
		/////////////////
		//ս������
		//////////////////
	case GAME_BATTLE_END:
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case VK_RETURN:
				m_map[Hero.GetFloor()].Block[BattleWithNow._x][BattleWithNow._y] = 0;
				


				Hero.EarnExp(BattleWithNow.Exp);
				Hero.m_mItem[(char)228] += BattleWithNow.Gold;

				m_gameState = GAME_STATE::GAME_RUNNING;
				DisableAttackEffect();


				if (Hero.GetFloor() == 9 && BattleWithNow._x == 5 && BattleWithNow._y == 7){
					m_gameState = GAME_WIN;
					m_subState.GameWin.Enable = true;
					m_subState.GameWin.fTime = fTime();
					break;
				}
				break;
			}

		default:
			break;
		}
		break;

		/////////////////
		//ս��
		//////////////////
	case GAME_BATTLE:
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case 'Q':
				m_gameState = GAME_STATE::GAME_RUNNING;
				DisableAttackEffect();
				break;
			case VK_LEFT:
				DEBUG_BATTLE_X--;
				break;
			case VK_RIGHT:
				DEBUG_BATTLE_X++;
				break;
			case VK_UP:
				DEBUG_BATTLE_Y--;
				break;
			case VK_DOWN:
				DEBUG_BATTLE_Y++;
				break;

			}
		case WM_KEYUP:

			break;
		default:
			break;
		}
		break;
		/////////////////
		//��ͣ
		//////////////////
	case GAME_PAUSE:
		switch (uMsg){

		case WM_KEYDOWN:
			switch (wParam){
			case 'P':
				m_gameState = GAME_RUNNING;
				break;
			}
		default:
			break;
		}

		break;
		/////////////////
		//��Ϸ����
		//////////////////
	case GAME_RUNNING:
		switch (uMsg){

		case WM_KEYDOWN:

			/////////////////
			//
			// �Ѱ��������¼����
			//
			/////////////////
			m_KeyState[wParam] = KEYDOWN;

			
			
//////////////////////
// ���Ŀ��λ�����ƶ������ƶ���Ŀ��λ��
// �������Ŀ��λ�����ܳԵĵ��߾ͳԵ���
// �������Ŀ��λ�����Ŷ�����Կ�׾Ϳ���
// �������Ŀ��λ���ܶԻ��ͶԻ�
// �������Ŀ��λ���ܶ�ս�Ͷ�ս
//////////////////////


			switch (wParam){
			case VK_UP:
				Sound.Play(L"Sound 272.wav", fTime());
				if (Hero.GetPosition().x - 1 < 0){ Hero.SetDirection(up); break; }
				if (CanWalkOn(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x - 1][Hero.GetPosition().y]))
					Hero.Move(up, 1);
				else { 
					Hero.SetDirection(up); 
					if (TryEat(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x - 1][Hero.GetPosition().y])){
						m_map[Hero.GetFloor()].Block[Hero.GetPosition().x - 1][Hero.GetPosition().y] = 0;
					}
					TryOpen(Hero.GetPosition().x-1,Hero.GetPosition().y);
					TryBattle(Hero.GetPosition().x - 1, Hero.GetPosition().y);
					if (CanTalkTo(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x - 1][Hero.GetPosition().y])){
						TryTalkTo(Hero.GetPosition().x - 1, Hero.GetPosition().y);
					
					}
				}
			
				break;
			case VK_DOWN:
				Sound.Play(L"Sound 272.wav", fTime());
				if (Hero.GetPosition().x + 1 >= Map_Width){ Hero.SetDirection(down); break; }
				if (CanWalkOn(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x + 1][Hero.GetPosition().y]))
					Hero.Move(down, 1);
				else { 
					Hero.SetDirection(down); 
					if (TryEat(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x + 1][Hero.GetPosition().y]))
						m_map[Hero.GetFloor()].Block[Hero.GetPosition().x + 1][Hero.GetPosition().y] = 0;
					TryOpen(Hero.GetPosition().x+1, Hero.GetPosition().y);
					TryBattle(Hero.GetPosition().x + 1, Hero.GetPosition().y);
					if (CanTalkTo(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x + 1][Hero.GetPosition().y])){
						TryTalkTo(Hero.GetPosition().x + 1, Hero.GetPosition().y);
					}

				}
				break;
			case VK_LEFT:
				Sound.Play(L"Sound 272.wav", fTime());
				if (Hero.GetPosition().y - 1 < 0){ Hero.SetDirection(Direction::left); break; }
				if (CanWalkOn(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y - 1]))
					Hero.Move(Direction::left, 1);
				else { 
					Hero.SetDirection(Direction::left);
					if (TryEat(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y - 1]))
						m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y - 1] = 0;
					TryOpen(Hero.GetPosition().x, Hero.GetPosition().y-1);
					TryBattle(Hero.GetPosition().x, Hero.GetPosition().y - 1);
					if (CanTalkTo(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y - 1])){
						TryTalkTo(Hero.GetPosition().x, Hero.GetPosition().y - 1);
					}
				}
				break;
			case VK_RIGHT:
				Sound.Play(L"Sound 272.wav", fTime());
				if (Hero.GetPosition().y + 1 >= Map_Width){ Hero.SetDirection(Direction::right); break; }
				if (CanWalkOn(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y + 1]))
					Hero.Move(Direction::right, 1);
				else { 
					Hero.SetDirection(Direction::right);
					if (TryEat(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y + 1]))
						m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y + 1] = 0;
					TryOpen(Hero.GetPosition().x, Hero.GetPosition().y+1);
					TryBattle(Hero.GetPosition().x, Hero.GetPosition().y + 1);
					if (CanTalkTo(m_map[Hero.GetFloor()].Block[Hero.GetPosition().x][Hero.GetPosition().y + 1])){
						TryTalkTo(Hero.GetPosition().x, Hero.GetPosition().y + 1);
					}
				}
				break;
			case 'P':
				m_gameState = GAME_PAUSE;
				
				break;
			case 'D':
				CheckMonsterInFloor();
				break;
			case 'E':
			case 'S':
				SaveGame(1);
				PopCaption(L"������Ϸ�ɹ�");
				break;
			case 'A':
			case 'L':
				LoadGame(1);
				PopCaption(L"��ȡ��Ϸ�ɹ�");
				break;
			case'G':
				if (Hero.m_mItem[(char)228] >= m_subState.nShopNeedGold){
					Hero.EarnAttack(3); 
					Hero.m_mItem[(char)228] -= m_subState.nShopNeedGold ;
					cstring.Format(L"3�㹥����,����%d���", m_subState.nShopNeedGold);
					PopCaption(cstring);
					m_subState.nShopNeedGold++;

				}
				else{
					cstring.Format(L"ʲô��û��,��Ҫ%d���", m_subState.nShopNeedGold);
					PopCaption(cstring);
				}
				break;
			
			case'F':
				if (Hero.m_mItem[(char)228] >= m_subState.nShopNeedGold){
					Hero.EarnDefense(4);
					Hero.m_mItem[(char)228] -= m_subState.nShopNeedGold;
					cstring.Format(L"4�������,����%d���", m_subState.nShopNeedGold);
					PopCaption(cstring);
					m_subState.nShopNeedGold++;
				}
				else{
					cstring.Format(L"ʲô��û��,��Ҫ%d���", m_subState.nShopNeedGold);
					PopCaption(cstring);
				}
				//m_subState.nShopNeedGold
				break;

			case VK_RETURN:
				//PopTip(L"ǿ�д򿪶Ի���");

				//PopCaption(L"�Ӷ౦һ�䣬����ϵ�ͷ���ȡ");
				//if (Random(0.0))PopCaption(L"��");
				//else	 PopCaption(L"��");
				break;
			default:
				break;
			}
			break;
		case WM_KEYUP:
			m_KeyState[wParam] = KEYUP;

			break;

		default:
			break;
		}
		break;
	//case GAME_PAUSE:
		break;
	//case GAME_POP_MENU:
		break;
	//case GAME_AUDIO_MENU:
		break;
	//case GAME_VIDEO_MENU:
		break;
	//case GAME_OVER:
		break;
	default:
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


//��ȡ����Ϸ��ʼ�����ھ�����ʱ��(s)
float CGame::fTime(){
	SYSTEMTIME		sTime;
	GetSystemTime(&sTime);
	static WORD		wLastSecond = sTime.wSecond;
	
	;//����Ϸ��ʼ�����ھ�����ʱ��(ms)
	if (sTime.wSecond != wLastSecond){
		wLastSecond = sTime.wSecond;
		m_fTime = (int)m_fTime + sTime.wMilliseconds / 1000.0f;
		m_fTime++;

	}
	else{
		m_fTime = (int)m_fTime + sTime.wMilliseconds / 1000.0f;
	}
	return m_fTime;
}
Vector CGame::GetScreenResolution(){
	DEVMODE NewDevMode;
	EnumDisplaySettings(0, ENUM_CURRENT_SETTINGS, &NewDevMode);
	static Vector _v;
	_v = Vector(Point((int)NewDevMode.dmPelsWidth, (int)NewDevMode.dmPelsHeight));
	return _v;
}

Vector CGame::GetConfigResolution(){
	return Vector(m_gameConfig.SCREEN_WIDTH,m_gameConfig.SCREEN_HEIGHT);

}


bool CGame::SetScreenResolution(Vector _v){

	//return ChangeDisplaySettings(&NewDevMode, CDS_FULLSCREEN);

	DEVMODE dmScreenSettings;
	memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));
	dmScreenSettings.dmSize = sizeof(dmScreenSettings);
	dmScreenSettings.dmBitsPerPel = 32;
	dmScreenSettings.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL;
	dmScreenSettings.dmPelsWidth = _v.x;
	dmScreenSettings.dmPelsHeight = _v.y;
	bool bRetn = (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN)!=0);
	if(bRetn) m_vResolution = Vector(_v);
	return bRetn;

}


bool CGame::SetScreenResolution(int _x, int _y){
	return SetScreenResolution(Vector(Point(_x, _y)));
}

int CGame::GetConfigFps(){
	return m_gameConfig.FPS;

}

BOOL CGame::IsVerticalSync(){
	return m_gameConfig.VERTICAL_SYNC;

}

BOOL CGame::IsPerformancePrior(){
	return m_gameConfig.PERFORMANCE_PRIOR;
}

fVector	CGame::GetUnitScale(){
	return m_fUnitScale;
}
void CGame::DisableAttackEffect(){
	m_mD2DGif["slash"].Disable();
	m_mD2DGif["slashb"].Disable();
	m_mD2DGif["fist"].Disable();
	m_mD2DGif["fistb"].Disable();
	m_mD2DGif["sword"].Disable();
	m_mD2DGif["swordb"].Disable();
	m_mD2DGif["water"].Disable();
	m_mD2DGif["suck"].Disable();
	m_mD2DGif["suckb"].Disable();
	m_mD2DGif["flash"].Disable();
	m_mD2DGif["explode"].Disable();
	m_mD2DGif["poision"].Disable();
	m_mD2DGif["nuclear"].Disable();
	m_mD2DGif["greenlaser"].Disable();

	m_mD2DGif["laser"].Disable();

	m_mD2DGif["magic"].Disable();
	m_mD2DGif["fire"].Disable();
	m_mD2DGif["fireb"].Disable();
	m_mD2DGif["firesword"].Disable();
	m_mD2DGif["fireswordb"].Disable();
	m_mD2DGif["ice"].Disable();
	m_mD2DGif["iceb"].Disable();
	m_mD2DGif["curse"].Disable();
	m_mD2DGif["curseb"].Disable();
	m_mD2DGif["barrage"].Disable();
	m_mD2DGif["barrageb"].Disable();
}

bool	CGame::CanWalkOn(char _block){
	switch (_block)
	{
	case 0x00:
		
		return true;
	case (char)246:
		m_subState.nFloorToGoto=Hero.GetFloor() - 1;
		m_AlphaChangeEffect.fAlphaNow = 0;
		m_AlphaChangeEffect.isIncrease = true;
		Sound.Play(L"Sound 1617.wav", fTime());
		m_gameState = GAME_STATE::GAME_TRANSITION;
		return true;
		break;
	case (char)247:
		m_subState.nFloorToGoto = Hero.GetFloor() + 1;
		m_AlphaChangeEffect.fAlphaNow = 0;
		m_AlphaChangeEffect.isIncrease = true;
		Sound.Play(L"Sound 1617.wav", fTime());
		m_gameState = GAME_STATE::GAME_TRANSITION;
		return true;
		break;
	default:
		break;
	}
	return false;

}



bool	CGame::CanTalkTo(char _block){
	switch (_block)	{
	case (char)71:
	case (char)72:
	case (char)73:
	case (char)74:

		return true;
	default:
		break;
	}
	return false;

}


bool	CGame::TryEat(char _block){
	CString cstring;
	switch (_block){
	case (char)209://��Կ��
		Hero.EarnAttack(SWORD1_ATTACK);
		cstring.Format(L"����,������+%d", SWORD1_ATTACK);
		PopCaption(cstring);
		return true;
	case (char)210://��Կ��
		Hero.EarnAttack(SWORD2_ATTACK);
		cstring.Format(L"����,������+%d", SWORD2_ATTACK);
		PopCaption(cstring);
		return true;
	case (char)211://��Կ��
		Hero.EarnAttack(SWORD3_ATTACK);
		cstring.Format(L"��ʿ��,������+%d", SWORD3_ATTACK);
		PopCaption(cstring);
		return true;
	case (char)212://��Կ��
		Hero.EarnAttack(SWORD4_ATTACK);
		cstring.Format(L"��ʯ��,������+%d", SWORD4_ATTACK);
		PopCaption(cstring);
		return true;
	case (char)213://��Կ��
		Hero.EarnAttack(SWORD5_ATTACK);
		cstring.Format(L"��ʥ��,������+%d", SWORD5_ATTACK);
		PopCaption(cstring);
		return true;
	case (char)214://��Կ��
		Hero.EarnDefense(SHIELD1_DEFENSE);
		cstring.Format(L"��ʿ��,������+%d", SHIELD1_DEFENSE);
		PopCaption(cstring);
		return true;
	case (char)215://��Կ��
		Hero.EarnDefense(SHIELD2_DEFENSE);
		cstring.Format(L"����,������+%d", SHIELD2_DEFENSE);
		PopCaption(cstring);
		return true;
	case (char)216://��Կ��
		Hero.EarnDefense(SHIELD3_DEFENSE);
		cstring.Format(L"����,������+%d", SHIELD3_DEFENSE);
		PopCaption(cstring);
		return true;
	case (char)217://��Կ��
		Hero.EarnDefense(SHIELD4_DEFENSE);
		cstring.Format(L"��ʯ��,������+%d", SHIELD4_DEFENSE);
		PopCaption(cstring);
		return true;
	case (char)218://��Կ��
		Hero.EarnDefense(SHIELD5_DEFENSE);
		cstring.Format(L"��ʥ��,������+%d", SHIELD5_DEFENSE);
		PopCaption(cstring);
		return true;
	case (char)225:
		Hero.m_mItem[_block]++;
		PopCaption(L"��Կ��");
		return true;
	case (char)226:
		Hero.m_mItem[_block]++;
		PopCaption(L"��Կ��");
		return true;
	case (char)227:
		Hero.m_mItem[_block]++;
		PopCaption(L"��Կ��");
		return true;
	case (char)228:
		Hero.m_mItem[_block]+=GOLD_EARN_GOLD;
		PopCaption(L"��ң���Ǯ+200");
		return true;
	case (char)229:
		Hero.m_mItem[(char)225]++;
		Hero.m_mItem[(char)226]++;
		Hero.m_mItem[(char)227]++;
		PopCaption(L"����Կ�ף�����Կ��+1");
		return true;
	case (char)230:
		Hero.EarnHP(RED_POTION_EARN_HP);//��ҩˮ
		PopCaption(L"��ҩƿ������+150");
		return true;
	case (char)231:
		Hero.EarnHP(BLUE_POTION_EARN_HP);//��ҩˮ
		PopCaption(L"��ҩƿ������+400");
		return true;
	case (char)232:
		Hero.EarnAttack(GEM_EARN_ATTACK);
		PopCaption(L"�챦ʯ��������+2");
		return true;
	case (char)233:
		Hero.EarnDefense(GEM_EARN_DEFENSE);
		PopCaption(L"����ʯ��������+2");
		return true;
	case (char)234:

		return true;
	case (char)235:

		return true;
	case (char)236:

		return true;
	case (char)237:

		return true;
	case (char)238:

		return true;
	case (char)239:

		return true;
	case (char)240:
		Hero.EarnSwift(GEM_EARN_SWIFT);
		PopCaption(L"�̱�ʯ������+1");
		return true;


	default:
		break;
	}
	return false;

}

//        /@^     .@@^           .@@`     =@@`          =@^       =@@.         ].  @@^          =@^     
//         ,@@`   /@^            =@^      @@`           =@^  =@@@@@@@@@@@@@`  =@/  @@^     .]]. =@^     
//      .@@@@@@@@@@@@@@^      =@@@@@@@@^ =@@@@@@@@^  ,]]/@\]`=@^ .       O@. ,@@[[[@@/[[[[. @@. =@^     
//      .@@          =@^      =@@    =@^=@/     =@^     =@^     /@/` ,@@`     ..   @@^      @@. =@^     
//      .@@          =@^      =@@    =@/\^ ]    =@^     =@^   /@@`     =@@`  [[[[[[@@/[[[[` @@. =@^     
//      .@@@@@@@@@@@@@@^      =@@@@@@@@^  =@\   =@^    ./@@@^ ,`        .`         @@^      @@. =@^     
//            ,@\     .`      =@@    =@^   =@\  =@^  =@@\@^   [[[[[@@[[[[[    =@/[[@@/[[@@^ @@. =@^     
//     =@^ @@. ,@@`   \@@`    =@@    =@^    [.  =@.     =@^        @@.        =@^  @@^  @@^.@@. =@^     
//    ,@/  @@.  .`  .` .\@\.  =@@]]]]/@^        @@.     =@^        @@.        =@^  @@^,]@@.     =@^     
//   .@@.  @@].    ,/@/       =@@    =@^   ,]]]/@@    ,]/@^ .@@@@@@@@@@@@@@^  ,[`  @@^.[`    .]]@@^   
bool CGame::OnFrameStart(HWND hWnd, float fTime){
	//static PAINTSTRUCT ps;


	//������Ϣ������Ϸ״̬��
	//StateProc();
	//�������紫��
	//NetTrans();
	//���ݷ��������ص���Ϣִ�в�ͬ�Ķ���,������Ϊ
	//Behaviour(float fTime);
	Behaviour.Execute(fTime);
	//�˹�����
	//Ai.Handle(fTime);
	//��������(���岥��������CSound��Wav����)
	//Sound();

	
	if (m_gameState==GAME_STATE::GAME_BATTLE)Battle(fTime);




	//��Ⱦ����
	Render(fTime);


	return true;
}


#define TalkToPos(f,x,y,DoWhat) if (Hero.GetFloor() == f && _x == x && _y == y){DoWhat;}
#define Dialog(content) PopTip(content,_x,_y);
#define DialogEx(content,title) PopTip(content,_x,_y,title);
#define Gift(xp,yp)m_subState.bGiftReceiving = true;m_subState.GiftFromPos.x = xp;m_subState.GiftFromPos.y = yp;
bool	CGame::TryTalkTo(int _x, int _y){

	TalkToPos(1, 6, 1,
		DialogEx(L"��ӭ�������ϴ�ѧCTF������\n���\%d���ħ����ȡflag\n��D���Բ鿴���������~\n", L"����"));
	
	TalkToPos(8, 1, 1,
		DialogEx(L"¥�Ͼ���BOSS��Ŷ��\n��������������õ�flag\n��S/A���Դ浵/����\n�򲻹����Զ�򼸴�~(������)", L"ѧ��"));

	TalkToPos(1, 12, 9,
		DialogEx(L"�������\n��F8�ܸ��ķֱ���", L"����"));

	TalkToPos(2, 12, 6,
		DialogEx(L"�����˶Ի����Խ�����Ʒ\n�����˶Ի������һЩ\n���õ���Ϣ", L"С͵"));
	TalkToPos(2, 12, 12,
		DialogEx(L"��3L���������������\n����Ҫ�Ķ���", L"����"));

	TalkToPos(3, 10, 2,
		DialogEx(L"��g���ӹ�����", L"����"));

	TalkToPos(3, 12, 12,
		DialogEx(L"��Ϣһ�°�\n��P������ͣ��Ϸ", L"����"));
	TalkToPos(3, 5, 12,
		DialogEx(L"��f���ӷ�����", L"����"));

	TalkToPos(4, 12, 1,
		DialogEx(L"��flag�ˣ�\nֻҪ5800���\n�ٺ� ��ʵ��Ҳ��֪��flag..", L"����"));

	TalkToPos(4, 12, 12,
		DialogEx(L"ħ����ʵ���ڵ�9��\n��������Ի��flag", L"����"));

	TalkToPos(5, 4, 1,
		DialogEx(L"��һЩ������ʵ��û��\nʲô����\n��Ϊ��Ƶ����벻������=_=", L"����"));

	TalkToPos(5, 4, 6,
		DialogEx(L"��ܵ�8������öӳ���\n��NPC�Ի�\n�������һЩ���õ���Ϣ", L"����"));

	TalkToPos(6, 12, 5,
		DialogEx(L"��������˵\n��������Ϸ���̫����", L"����"));

	TalkToPos(6, 11, 9,
		DialogEx(L"�������д�����Կ��\n����ҪʲôԿ��?\nʲô,��Կ����\n��Կ�ף�9999999999", L"����"));



	TalkToPos(1, 0, 7,
		Dialog(L"��֪����\nԤ����һ��ֻ������\n�������öӳ���Ӯ��\n�ٺٺ�"););

	TalkToPos(2, 3, 2,
		Dialog(L"��Ȼ�㶼�ҵ�����\n�Ǿ͸���20����10����\nף�����մ�����öӳ�~\n��ʽ����Ҫ�շѵ�Ŷ~"); Gift(3,2);;);

	TalkToPos(3, 13,0,
		Dialog(L"лл���������\n�������д�����Կ��\nȫ��������~\n��ʽ����Ҫ�շѵ�Ŷ~"); Gift(13,0););



	TalkToPos(1, 9, 2, 
		DialogEx(L"���ϣ�С����\n��ˤ����\n�����һ��", L"�ϴ�ү"));
		
	TalkToPos(1, 9, 5, 
		Dialog(L"�������д�����Կ��\n����ҪʲôԿ��?\nʲô,��Կ����\n��Կ�ף�9999999999"););

	TalkToPos(1, 9, 7, 
		Dialog(L"���\nû��ʱ�������\n���ϳ�"););


	//TalkToPos()
	
	

	return true;
}

bool	CGame::TryOpen(int _x, int _y){

	switch (m_map[Hero.GetFloor()].Block[_x][_y])	{
	
	case (char)241:
		if (Hero.m_mItem[(char)225]){
			Hero.m_mItem[(char)225]--;
			m_map[Hero.GetFloor()].Block[_x][_y] = 0;
			m_mD2DGif["opendoor1"].SetPosition(Point(_x, _y));
			m_mD2DGif["opendoor1"].Reset();
			Sound.Play(L"Sound 564.wav", fTime());
			return true;
		}
		break;
	case (char)242:
		if (Hero.m_mItem[(char)226]){
			Hero.m_mItem[(char)226]--;
			m_map[Hero.GetFloor()].Block[_x][_y] = 0;
			m_mD2DGif["opendoor2"].SetPosition(Point(_x, _y));
			m_mD2DGif["opendoor2"].Reset();
			Sound.Play(L"Sound 564.wav", fTime());
			return true;
		}
		break;
	case (char)243:
		if (Hero.m_mItem[(char)227]){
			Hero.m_mItem[(char)227]--;
			m_map[Hero.GetFloor()].Block[_x][_y] = 0;
			m_mD2DGif["opendoor3"].SetPosition(Point(_x, _y));
			m_mD2DGif["opendoor3"].Reset();
			Sound.Play(L"Sound 564.wav", fTime());
			return true;
		}
		break;
	case (char)245:

		m_map[Hero.GetFloor()].Block[_x][_y] = 0;
		m_mD2DGif["openjail"].SetPosition(Point(_x, _y));
		m_mD2DGif["openjail"].Reset();
		Sound.Play(L"Sound 564.wav", fTime());
		return true;
	default:
		break;
	}
	return false;

}

bool	CGame::TryBattle(int _x, int _y){

	if (m_map[Hero.GetFloor()].Block[_x][_y]>0 && m_map[Hero.GetFloor()].Block[_x][_y]<=(char)MONSTER_COUNT)	{

		StartBattleWith(_x,_y);

		//m_map[Hero.GetFloor()].Block[_x][_y] = 0;
		return true;
	}
	return false;

}

#define ReceivePos(f,_x,_y,DoWhat)  if( m_subState.bGiftReceiving && Hero.GetFloor() == f && m_subState.GiftFromPos.x == _x && m_subState.GiftFromPos.y == _y){DoWhat;m_subState.bGiftReceiving=false;}

bool CGame::ReceiveGift(){
	
	ReceivePos(2, 3, 2,Hero.EarnAttack(20); Hero.EarnDefense(10);m_map[2].Block[3][2] = 0;PopCaption(L"20������,10������"));
	
	ReceivePos(3, 13, 0,
		Hero.m_mItem[(char)225] += 2; Hero.m_mItem[(char)226] += 3; Hero.m_mItem[(char)227] += 1; 	m_map[3].Block[13][0] = 0;
	PopCaption(L"��Կ�ס�2,��Կ�ס�3����Կ�ס�1"));


	
	return true;
}


bool CGame::StartBattleWith(int _x,int _y){
	//��data/monster.dat��ȡ����
	char cBuff[MAX_STRING_LENGTH];
	int n;
	BattleWithNow.Monster = m_map[Hero.GetFloor()].Block[_x][_y];
	n = (int)BattleWithNow.Monster;
	BattleWithNow.MonsterName = m_mMonster[n].Name;
	BattleWithNow.HP = m_mMonster[n].HP;
	BattleWithNow.Attack = m_mMonster[n].Attack;
	BattleWithNow.Defense = m_mMonster[n].Defend;
	BattleWithNow.Swift = m_mMonster[n].Swift;
	BattleWithNow.MonsterAttackTimes = m_mMonster[n].Combo;
	BattleWithNow.MonsterHasAttacked = 0;
	BattleWithNow.Ability = m_mMonster[n].Ability;
	BattleWithNow.Hemophagia = m_mMonster[n].Hemophagia / 100.0f;
	BattleWithNow.Critical = m_mMonster[n].Critical / 100.0f;
	BattleWithNow.CriticalRatio = m_mMonster[n].CriticalRatio / 100.0F;
	BattleWithNow.HeroAttackTimes = 1;
	BattleWithNow.Exp = m_mMonster[n].Exp;
	BattleWithNow.Gold = m_mMonster[n].Gold;
	BattleWithNow.Weapon = m_mMonster[n].Weapon;
	BattleWithNow._x = _x;
	BattleWithNow._y = _y;


	m_gameState = GAME_STATE::GAME_BATTLE;
	BattleWithNow.bJustStart = true;

	return true;
}

//����һҳ�ĶԻ����޸�ConversationWithNow.vSentences
bool CGame::PopTip(CString _text, int _x, int _y, CString sTitle){
	m_AlphaChangeEffect.fAlphaNow = 1.0F;
	m_AlphaChangeEffect.isIncrease = false;

	if (!_text.IsEmpty()) { 
		ConversationWithNow.vSentences.clear(); 
		ConversationWithNow.vSentences.push_back(_text);
	}
	if (sTitle.IsEmpty()){
		switch (m_map[Hero.GetFloor()].Block[_x][_y]){
		case (char)71:
			sTitle = L"����";
			break;
		case (char)72:
			sTitle = L"����";
			break;
		case (char)73:
			sTitle = L"����";
			break;
		case (char)74:
			sTitle = L"����";
			break;
		}

	}
	ConversationWithNow.sTitle = sTitle;
		

	ConversationWithNow._x = _x;
	ConversationWithNow._y = _y;
	ConversationWithNow.nSentenceNow = 1;
	m_gameState = GAME_STATE::GAME_TIP;

	return true;
}


bool	CGame::PopCaption(CString _text){

	m_subState.csCaptionString = _text;
	m_gameState = GAME_CAPTION;
	Sound.Play(L"Sound 1615.wav", fTime());
	return true;
}
bool	CGame::CheckMonsterInFloor(){

	m_gameState = GAME_STATE::GAME_CHECK_MONSTER;

	int nBuff;

	m_subState.sMonsterChecker.sMonsterIds.clear();

	for (int i = 0; i < Map_Width; i++){
		for (int j = 0; j < Map_Width; j++){
			nBuff = m_map[Hero.GetFloor()].Block[i][j];
			if (nBuff>0 && nBuff <= MONSTER_COUNT){
				m_subState.sMonsterChecker.sMonsterIds.insert(nBuff);
			}
		}
	}
	if (!m_subState.sMonsterChecker.sMonsterIds.size())m_subState.sMonsterChecker.nPageCount = 0;
	else m_subState.sMonsterChecker.nPageCount = (m_subState.sMonsterChecker.sMonsterIds.size() - 1) / 3 + 1;

	m_subState.sMonsterChecker.nPageNow = 1;
	m_subState.sMonsterChecker.nPageItemsCount = (m_subState.sMonsterChecker.sMonsterIds.size()>3 ? (3) : (m_subState.sMonsterChecker.sMonsterIds.size()));

	return true;
}

int CGame::ComputeHarm(int _monster){

	int nMonsHarm=m_mMonster[_monster].Attack - Hero.GetDefense();
	int nHeroHarm = Hero.GetAttack()-m_mMonster[_monster].Defend;
	if (nHeroHarm <= 0)return -1;
	if (m_mMonster[_monster].Ability != (L"��ʦ") && nMonsHarm <= 0)return 0;
	int nHeroTimes = ceil(m_mMonster[_monster].HP / (nHeroHarm*1.0f));
	int nMonsTimes = (nHeroTimes - 1)*m_mMonster[_monster].Combo;
	if (m_mMonster[_monster].Ability == (L"��ʦ"))return m_mMonster[_monster].Attack*nMonsTimes;
	return (nMonsHarm*nMonsTimes);

}

bool	CGame::Battle(float fTime){
	static float fLastTime = 0;
	string strattackB;

	if (BattleWithNow.bJustStart){
		fLastTime = fTime - BATTLE_DELAY_TIME*0.8f;
		BattleWithNow.bJustStart = false;
		return true;
	}
	if (BattleWithNow.bJustEnd){
		fLastTime = fTime - BATTLE_DELAY_TIME*0.3f;
		BattleWithNow.bJustEnd = false;
		return true;
	}
	else if (BattleWithNow.bJustChange==true){
		
		if (fTime - fLastTime < BATTLE_DELAY_TIME){
			return true;
		}
		//else if(fTime - fLastTime>BATTLE_DELAY_TIME * 2){
		//	fLastTime = fTime;
		//	return true;
		//}
		else {
			fLastTime = fTime;
		}
	}
	else if(BattleWithNow.bJustChange == false){
		if (BattleWithNow.Monster == (char)34){
			if (fTime - fLastTime < BATTLE_DELAY_TIME){
				return true;
			}
			else {
				fLastTime = fTime;
			}
		}
		else{
			if (fTime - fLastTime < BATTLE_COMBO_TIME){
				return true;
			}
			else {
				fLastTime = fTime;
			}
		}
	}
	
	if (BattleWithNow.HP == 0) { 
		//m_map[Hero.GetFloor()].Block[BattleWithNow._x][BattleWithNow._y] = 0;
		Sound.Play(L"Sound 1350.wav", fTime);
		m_gameState = GAME_STATE::GAME_BATTLE_END;
		return true;
	}
	if (Hero.GetHP() == 0){ 
		m_gameState = GAME_STATE::GAME_OVER; 
		m_subState.GameOver.Enable = true;
		m_subState.GameOver.fTime = fTime;
	}//Game Over

	//ս���Ļغ�
	//Ӣ�۹���
	if (BattleWithNow.HeroAttackTimes){
		if (BattleWithNow.MonsterAttackTimes)BattleWithNow.HeroAttackTimes--;
		if (!BattleWithNow.HeroAttackTimes){ 
			BattleWithNow.MonsterHasAttacked = 0; 
			BattleWithNow.bJustChange = true;
		}else BattleWithNow.bJustChange = false;
		if (Hero.GetAttack() > BattleWithNow.Defense) { 
			//����miss
			if (Random(BattleWithNow.Swift/ 100.0f)){
			
				Sound.PlayAlias("miss", fTime);
				m_subState.MonsterMiss.fTime = fTime;
				m_subState.MonsterMiss.Enable = true;
			}
			else{
				m_mD2DGif["heroslash"].Reset();
				Sound.PlayAlias("sword", fTime);
				BattleWithNow.HP -= abs(Hero.GetAttack() - BattleWithNow.Defense);
			}
		}
		if (BattleWithNow.HP <= 0){ 
			BattleWithNow.HP = 0; 
			BattleWithNow.MonsterAttackTimes = 0; 
			BattleWithNow.bJustEnd = true;
		}
	}//���﹥��
	else{
		BattleWithNow.MonsterHasAttacked++;
		if (BattleWithNow.MonsterHasAttacked == BattleWithNow.MonsterAttackTimes){
			BattleWithNow.HeroAttackTimes = 1;
			BattleWithNow.bJustChange = true;
		}else BattleWithNow.bJustChange = false;
		if (BattleWithNow.Ability==(L"��ʦ") || BattleWithNow.Attack > Hero.GetDefense()){
			//Ӣ��MISS
			if (Random(Hero.GetSwift() / 100.0f)){
				Sound.PlayAlias("miss", fTime);
				m_subState.HeroMiss.fTime = fTime;
				m_subState.HeroMiss.Enable = true;
			}
			else{
				//���ﱩ��
				if (Random(BattleWithNow.CriticalRatio)){
					strattackB = BattleWithNow.Weapon + "b";
					m_mD2DGif[strattackB].Reset();
				
					Sound.PlayAlias(strattackB, fTime);
					if (BattleWithNow.Ability == (L"��ʦ"))Hero.EarnHP(-BattleWithNow.Attack*BattleWithNow.Critical);
						else Hero.EarnHP(-abs((int)(BattleWithNow.Critical *(BattleWithNow.Attack - Hero.GetDefense()))));
					
				}//����û����
				else{
					if (BattleWithNow.Weapon== "barrage")m_mD2DGif["hit"].Reset();
					if (BattleWithNow.Weapon == "fire")m_mD2DGif["hit"].Reset();
					m_mD2DGif[BattleWithNow.Weapon].Reset();
					Sound.PlayAlias(BattleWithNow.Weapon, fTime);
					if (BattleWithNow.Ability == (L"��ʦ"))Hero.EarnHP(-BattleWithNow.Attack);
						else Hero.EarnHP(-abs(BattleWithNow.Attack - Hero.GetDefense()));


				}


			}
			


		}
		if (Hero.GetHP() < 0){
			Hero.EarnHP(-Hero.GetHP());
			m_gameState = GAME_STATE::GAME_OVER;
			Sound.Play(L"Sound 1375.wav", fTime);
			m_subState.GameOver.Enable = true;
			m_subState.GameOver.fTime = fTime;
		}
	}

	return true;
}

////////////////////////////////////
//
//  ��Ϸ״̬������SAVE LOAD
//
////////////////////////////////////

BYTE CGame::GetPlotState(string _plot){
	return GetPlotState(m_mPlotState[_plot]);
}

BYTE CGame::GetPlotState(int _where){

	return m_byPlotState[_where];
}

void CGame::SetPlotState(string _plot, BYTE _plotstate){
	SetPlotState(m_mPlotState[_plot], _plotstate);
}

void CGame::SetPlotState(int _where, BYTE _plotstate){
	m_byPlotState[_where] = _plotstate;

}

//                   ]]/`                          .]]].                                                                          
//   ./@@\.          .@@\              ,@@@\`       @@/                .@@@@@@@@@@@@@@@@@@@@@@^       ]@\  .@@^ .@@^  =@@^        
//     ,\@@@`@@@@@@@@@@@@@@@@@@@@`        [@@` .]]]]@@\]]]]]`                          .]@@@@[`        =@@`.@@^./@/   @@/         
//       .[  O@@              =@@.   .@\`      .[[[[@@/[[[@@^                      ,/@@@/`           ,]]]]]]@@\]]/]]`=@@`         
//           @@@              =@@.    ,\@@@\       =@@.  .@@^              /]    .@@/`   ..          =@@@@@@@@@@@@@@^@@@@@@@@@@@O 
//  ,@@@].     .@@@@@@@@@@@@@@O          .`,@^    /@@`   .@@`  ,          .\@@\. .@@^  ,@@@\            ,@@/@@\/\.  =@@.    @@^   
//    ,\@@@`                            ./@@@`  ]@@@.    ,@@.  @@@.   =@@.   ,@/ .@@^,@@@`  .@@^     ,/@@/ .@@^,@@\=@@@^   .@@^   
//       ,    .@@@@@@@@@@@@@@@@^     .]@@@/ ,]@@@/.      .@@@@@@@`    =@@.       .@@^       .@@^     ,@`  ,/[[`  `,@@\@\   ,@@.   
//            .@@^          =@@^      ,@`    .[` ,@@^                 =@@.   ./@`.@@^/@@`   .@@^    ..   .@@/      [`.@@`  =@/    
//     ./@\`  .@@@@@@@@@@@@@@@@^    .]]]]]]]]]]]]]@@\]]]]]]]]]]]].    =@@../@@@` .@@^ ,@@@` .@@^    .@@@@@@@@@@@@@@   =@@..@@^    
//     =@@`   .@@^          =@@^    .[[[[[[[[[[@@@@@@@@[[[[[[[[[[.    =@@.\@`    .@@^   ,@@/.@@^        =@@.   =@@.    \@\@@/     
//    ,@@^    .@@\]]]]]]]]]]/@@^            ./@@/.@@^\@@\.            =@@.    .@@@@@`       .@@^       =@@@@@\/@@`     .\@@/      
//   .@@@.    .[[[[[[[[[[[[[[[[`          ]@@@/. .@@^ .\@@@\`         =@@.     ,[           .@@^            ,@@@@@@\  ./@@@@\.    
//  ,@@@`                           .]/@@@@/`    .@@^    ,\@@@@@@/    =@@@@@@@@@@@@@@@@@@@@@@@@^        ,]@@@[    ,./@@@` .\@@@`  
//   .\^    O@@@@@@@@@@@@@@@@@@@@@   ,@/[        ,@@^         ,[`                           .@@^    .[@@@/`      ,@@@[      .\@@` 

#define XOFFSET 230
#define YOFFSET 35
#define LOADANILEFT_INIT 100
#define LOADANILEFT_ADD 3

bool CGame::Render(float fTime){

	static bool bPace = false;//��Ϊһ������֡ ������Ҫһ������
	int i = 0;
	char cBuff[30];
	WCHAR wBuff[30];
	set<int>::iterator it;
	CString cstring;

	Monster mBuff[3];

	static float fLastTime = 0;
	static int nLoadAniLeft = LOADANILEFT_INIT;
	static float fLoadShow = 0;

	if (fTime != 0){

			if (fTime - fLastTime < 1/((MAX_FPS)*1.0f)){
				return true;
			}
			else {
				fLastTime = fTime;
			}
		}



	switch (m_gameState){
	case GAME_MOTION:
		break;
		//��Ⱦ������
	case GAME_LOADING:

		

		

		WaitForSingleObject(RenderMutex, INFINITE);
		D2DC.BeginDraw();
		D2DC.ClearScreen(D2D1::ColorF::Black);
		
		


#ifdef DEBUG_PLAY
		if (nLoadAniLeft< LOADANILEFT_INIT + nLoadPercent * 6) nLoadAniLeft += LOADANILEFT_ADD*10;
		if (fLoadShow < nLoadPercent)fLoadShow += 5;
		if (fLoadShow < nLoadPercent-10 )fLoadShow += 10;
#else
		if (nLoadAniLeft< LOADANILEFT_INIT + nLoadPercent * 6) nLoadAniLeft += LOADANILEFT_ADD;
		if (nLoadAniLeft< LOADANILEFT_INIT + nLoadPercent * 6-40) nLoadAniLeft += LOADANILEFT_ADD*2;
		if (nLoadAniLeft< LOADANILEFT_INIT + nLoadPercent * 6-70) nLoadAniLeft += LOADANILEFT_ADD*4;

		if (fLoadShow < nLoadPercent)fLoadShow += 0.4;
		if (fLoadShow < nLoadPercent - 2)fLoadShow += 0.7;
		if (fLoadShow < nLoadPercent - 5)fLoadShow += 1;
#endif


		if (m_mD2DImage["loadback"].pBitMap())D2DC.DrawBmp(m_mD2DImage["loadback"], 100,-10,500, 500,1.0f, 0, 0, 800, 800);
		

		m_mD2DGif["loading"].Render(D2DC.pRenderTarget(), fTime, fPoint(nLoadAniLeft, 400), fVector(206 * 3, 180));

		cstring.Format(L"Loading %d%%", (int)fLoadShow);
	

		D2DC.DrawTextC(L"���������׭", 35, 240, 430, 0, 0, cstring,D2DRGB(255,255,255));

		
		
		//D2DC.EndDraw();

		//ReleaseSemaphore(RenderMutex, 1, NULL);

		break;
	case GAME_MAIN_MENU:
		break;
	case GAME_BATTLE:
	case GAME_TIP:
	case GAME_RUNNING:
	case GAME_PAUSE:
	case GAME_CHECK_MONSTER:
	case GAME_BATTLE_END:
	case GAME_OVER:
	case GAME_WIN:
	case GAME_CAPTION:
	case GAME_TRANSITION:
		WaitForSingleObject(RenderMutex, INFINITE);
		D2DC.BeginDraw();
		if (fTime != 0){
			static float fLastTime2 = 0;
			if (fTime - fLastTime2 < 1 / (Game.GetConfigFps()*1.0f)){
				//bPace����
				//return true;
			}
			else {
				if (m_gameState != GAME_PAUSE)bPace = !bPace;
				fLastTime2 = fTime;
			}
		}


		
		D2DC.ClearScreen(D2D1::ColorF::Gray);

		//int i = 1;
		//D2DC.DrawBmp(d2dImage[d2dImage.size() - 1], 100 ,100, 54, 54,1.0F,0,0,32,32);
		//D2DC.DrawBmp(m_mD2DImage["wall"], 0, 0, 32, 32, 1.0F, 0, 0, 32, 32);

		///////////////////
		//��������
		//////////////////
		D2DC.DrawBmp(m_mD2DImage["backbig"], 0, 0, 981, 621, 1.0F, 0, 0, 981, 621);

		/////////////////
		//¥��
		////////////////
#ifdef MAP_LARGE
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 5, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 6, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 7, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 8, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);

		if (Hero.GetFloor() > 0)_stprintf_s(wBuff, L"��  %2dF", Hero.GetFloor());
		else _stprintf_s(wBuff, L"�� B%2dF", Hero.GetFloor());

		D2DC.DrawTextB(L"����", 18, XOFFSET + 32 * 6, 5, XOFFSET + 32 * 5 + 200, 3 + 150, wBuff);

#else
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 4, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 5, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * 6, 0 + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);

		if (Hero.GetFloor()>0)_stprintf_s(wBuff, L"��  %2dF", Hero.GetFloor());
		else _stprintf_s(wBuff, L"�� B%2dF", Hero.GetFloor());

		D2DC.DrawTextB(L"����", 18, XOFFSET + 32 * 5 - 16, 5, XOFFSET + 32 * 5 + 200, 3 + 150, wBuff);
#endif


		//////////////////////////
		//
		//
		//  ��Ⱦ��ͼ
		//
		//
		/////////////////////////
		for (int i = 0; i < Map_Width; i++){
			for (int j = 0; j < Map_Width; j++){
				switch (m_map[Hero.GetFloor()].Block[i][j]){
				case 0x00:
					D2DC.DrawBmp(m_mD2DImage["floor"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)0xFF:
					D2DC.DrawBmp(m_mD2DImage["wall"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)71:
					strcpy_s(cBuff, "merchant");
					if (bPace)strcat_s(cBuff, "_2");
					else strcat_s(cBuff, "_1");
					D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)72:
					strcpy_s(cBuff, "oldman");
					if (bPace)strcat_s(cBuff, "_2");
					else strcat_s(cBuff, "_1");
					D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)73:
					strcpy_s(cBuff, "thief");
					if (bPace)strcat_s(cBuff, "_1");
					else strcat_s(cBuff, "_2");
					D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)74:
					strcpy_s(cBuff, "fairy");
					if (bPace)strcat_s(cBuff, "_1");
					else strcat_s(cBuff, "_2");
					D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)206:
					D2DC.DrawBmp(m_mD2DImage["badge1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)207:
					D2DC.DrawBmp(m_mD2DImage["badge2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)208:
					D2DC.DrawBmp(m_mD2DImage["badge3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)209:
					D2DC.DrawBmp(m_mD2DImage["sword1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)210:
					D2DC.DrawBmp(m_mD2DImage["sword2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)211:
					D2DC.DrawBmp(m_mD2DImage["sword3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)212:
					D2DC.DrawBmp(m_mD2DImage["sword4"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)213:
					D2DC.DrawBmp(m_mD2DImage["sword5"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)214:
					D2DC.DrawBmp(m_mD2DImage["shield1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)215:
					D2DC.DrawBmp(m_mD2DImage["shield2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)216:
					D2DC.DrawBmp(m_mD2DImage["shield3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)217:
					D2DC.DrawBmp(m_mD2DImage["shield4"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)218:
					D2DC.DrawBmp(m_mD2DImage["shield5"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)219:
					D2DC.DrawBmp(m_mD2DImage["cross"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)220:
					D2DC.DrawBmp(m_mD2DImage["wing2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)221:
					D2DC.DrawBmp(m_mD2DImage["wing3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)222:
					D2DC.DrawBmp(m_mD2DImage["wing1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)223:
					D2DC.DrawBmp(m_mD2DImage["holywater"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)225:
					D2DC.DrawBmp(m_mD2DImage["key1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)226:
					D2DC.DrawBmp(m_mD2DImage["key2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)227:
					D2DC.DrawBmp(m_mD2DImage["key3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)228:
					D2DC.DrawBmp(m_mD2DImage["gold"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)229:
					D2DC.DrawBmp(m_mD2DImage["key4"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)230:
					D2DC.DrawBmp(m_mD2DImage["potion1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)231:
					D2DC.DrawBmp(m_mD2DImage["potion2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)232:
					D2DC.DrawBmp(m_mD2DImage["gem1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)233:
					D2DC.DrawBmp(m_mD2DImage["gem2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)234:
					D2DC.DrawBmp(m_mD2DImage["potion3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)235:
					D2DC.DrawBmp(m_mD2DImage["potion4"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)236:
					D2DC.DrawBmp(m_mD2DImage["pickax1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)237:
					D2DC.DrawBmp(m_mD2DImage["pickax2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)238:
					D2DC.DrawBmp(m_mD2DImage["snow"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)239:
					D2DC.DrawBmp(m_mD2DImage["holyshield"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)240:
					D2DC.DrawBmp(m_mD2DImage["gem3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)241:
					D2DC.DrawBmp(m_mD2DImage["door1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)242:
					D2DC.DrawBmp(m_mD2DImage["door2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)243:
					D2DC.DrawBmp(m_mD2DImage["door3"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)244:
					D2DC.DrawBmp(m_mD2DImage["door4"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)245:
					D2DC.DrawBmp(m_mD2DImage["jail"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)246:
					D2DC.DrawBmp(m_mD2DImage["downstairs"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)247:
					D2DC.DrawBmp(m_mD2DImage["upstairs"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)251:
					if(bPace)D2DC.DrawBmp(m_mD2DImage["bramble_1"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					else D2DC.DrawBmp(m_mD2DImage["bramble_2"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)252:
					D2DC.DrawBmp(m_mD2DImage["magma"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)253:
					D2DC.DrawBmp(m_mD2DImage["dirt"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)254:
					D2DC.DrawBmp(m_mD2DImage["back"], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
					/*case (char) :

					break;
					case (char) :

					break;
					case (char) :

					break;
					case (char) :

					break;
					case (char) :

					break;

					case (char) :
					break;
					*/
				default:
					break;
				}
				//if (==0xFF)
				///////////////////////
				//
				//	��Ⱦ����
				//
				////////////////////////
				if (m_map[Hero.GetFloor()].Block[i][j] > 0 && m_map[Hero.GetFloor()].Block[i][j] <= (char)44){

					if (bPace){
						strcpy_s(cBuff, m_mMonster[(int)m_map[Hero.GetFloor()].Block[i][j]].IDString.data());
						strcat_s(cBuff, "_1");
					}
					else{
						strcpy_s(cBuff, m_mMonster[(int)m_map[Hero.GetFloor()].Block[i][j]].IDString.data());
						strcat_s(cBuff, "_2");
					}
					//if (!m_mD2DImage[cBuff].pBitMap())OutputDebugString(m_mMonster[(int)m_map[Hero.GetFloor()].Block[i][j]].Name);
					D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 32 * j, YOFFSET + 32 * i, 32, 32, 1.0F, 0, 0, 32, 32);


				}
			}

		}


		////////////////////////
		//
		//	��ȾӢ��
		//
		////////////////////////
		switch (Hero.GetDirection()){
		case up:
			if (m_KeyState[VK_UP] != KEYDOWN) D2DC.DrawBmp(m_mD2DImage["hero1u"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
			else{
				if (bPace)D2DC.DrawBmp(m_mD2DImage["hero1wu1"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
				else D2DC.DrawBmp(m_mD2DImage["hero1wu2"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
			};
			break;

		case down:
			if (m_KeyState[VK_DOWN] != KEYDOWN) D2DC.DrawBmp(m_mD2DImage["hero1d"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
			else{
				if (bPace)D2DC.DrawBmp(m_mD2DImage["hero1wd1"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
				else D2DC.DrawBmp(m_mD2DImage["hero1wd2"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);;
			};
			break;

		case Direction::left:
			if (m_KeyState[VK_LEFT] != KEYDOWN)D2DC.DrawBmp(m_mD2DImage["hero1l"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
			else{
				if (bPace)D2DC.DrawBmp(m_mD2DImage["hero1wl1"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
				else D2DC.DrawBmp(m_mD2DImage["hero1wl2"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);

			};
			break;

		case Direction::right:
			if (m_KeyState[VK_RIGHT] != KEYDOWN)D2DC.DrawBmp(m_mD2DImage["hero1r"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
			else{
				if (bPace) D2DC.DrawBmp(m_mD2DImage["hero1wr1"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);
				else D2DC.DrawBmp(m_mD2DImage["hero1wr2"], XOFFSET + 32 * Hero.GetPosition().y, YOFFSET + 32 * Hero.GetPosition().x, 32, 32, 1.0F, 0, 0, 32, 32);

			};
			break;

		default:
			break;
		}


#ifdef MAP_LARGE
		D2DC.DrawRectangle(XOFFSET - 1, YOFFSET - 1, XOFFSET + 32 * 14, YOFFSET + 32 * 14, 3.0F);
#else

		D2DC.DrawRectangle(XOFFSET  - 1, YOFFSET -1, XOFFSET +32*11, YOFFSET + 32*11, 3.0F);
#endif



		/////////////////////////////
		//
		//	��Ⱦ����
		//
		/////////////////////////////
#define FONT_SIZE 16
#define TITLE_LEFT 55
#define TITLE_TOP 60
#define TITLE_SPACE 25
#define ITEM_SPACE 33
#define ITEM_TOP 250
#define ITEM_LEFT 97
#define	DRAW_NEXT_TEXT(format,value) _stprintf_s(wBuff, format, value);D2DC.DrawTextB(L"�����������", FONT_SIZE, TITLE_LEFT, TITLE_TOP + TITLE_SPACE*i++, TITLE_LEFT + 150, TITLE_TOP + TITLE_SPACE*i + 100, wBuff);

		D2DC.DrawBmp(m_mD2DImage["infoback"], 32, 32, 161, 357, 1.0F, 0, 0, 161, 357);

		WCHAR wBuff[200];

		DRAW_NEXT_TEXT(L"�ȼ�:\t  %d", Hero.GetLevel());

		DRAW_NEXT_TEXT(L"����:\t  %d", Hero.GetHP());

		DRAW_NEXT_TEXT(L"������:\t  %d", Hero.GetAttack());

		DRAW_NEXT_TEXT(L"������:\t  %d", Hero.GetDefense());

		DRAW_NEXT_TEXT(L"����:\t  %d", Hero.GetSwift());

		DRAW_NEXT_TEXT(L"����ֵ:\t  %d", Hero.GetExp());



		D2DC.DrawBmp(m_mD2DImage["key1"], 53, 247, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["key2"], 53, 247 + ITEM_SPACE, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["key3"], 53, 247 + ITEM_SPACE * 2, 32, 32, 1.0F, 0, 0, 32, 32);
		D2DC.DrawBmp(m_mD2DImage["gold"], 53, 247 + ITEM_SPACE * 3, 32, 32, 1.0F, 0, 0, 32, 32);

		i = 0;
		_stprintf_s(wBuff, L"�� %-2d", Hero.m_mItem[(char)225]);
		D2DC.DrawTextB(L"�����������", FONT_SIZE + 8, ITEM_LEFT, ITEM_TOP + ITEM_SPACE*i++, ITEM_LEFT + 150, ITEM_TOP + ITEM_SPACE*i + 100, wBuff);
		_stprintf_s(wBuff, L"�� %-2d", Hero.m_mItem[(char)226]);
		D2DC.DrawTextB(L"�����������", FONT_SIZE + 8, ITEM_LEFT, ITEM_TOP + ITEM_SPACE*i++, ITEM_LEFT + 150, ITEM_TOP + ITEM_SPACE*i + 100, wBuff);
		_stprintf_s(wBuff, L"�� %-2d", Hero.m_mItem[(char)227]);
		D2DC.DrawTextB(L"�����������", FONT_SIZE + 8, ITEM_LEFT, ITEM_TOP + ITEM_SPACE*i++, ITEM_LEFT + 150, ITEM_TOP + ITEM_SPACE*i + 100, wBuff);
		_stprintf_s(wBuff, L"�� %-2d", Hero.m_mItem[(char)228]);
		D2DC.DrawTextB(L"�����������", FONT_SIZE + 8, ITEM_LEFT, ITEM_TOP + ITEM_SPACE*i++, ITEM_LEFT + 150, ITEM_TOP + ITEM_SPACE*i + 100, wBuff);


		//DRAW_NEXT_TEXT(L"��Կ��:\t  %d��", Hero.m_mItem[(char)225]);

		//DRAW_NEXT_TEXT(L"��Կ��:\t  %d��", Hero.m_mItem[(char)226]);

		//DRAW_NEXT_TEXT(L"��Կ��:\t  %d��", Hero.m_mItem[(char)227]);

		//DRAW_NEXT_TEXT(L"��Ǯ:\t  %d��", Hero.m_mItem[(char)228]);



		//////////////////////////////////
		//
		//	��Ⱦ����
		//
		//////////////////////////////////


		m_mD2DGif["opendoor1"].Render(D2DC.pRenderTarget(), fTime, fPoint(XOFFSET + 32 * m_mD2DGif["opendoor1"].GetPosition().y + 16, YOFFSET + 32 * m_mD2DGif["opendoor1"].GetPosition().x + 16), fVector(32, 32));
		m_mD2DGif["opendoor2"].Render(D2DC.pRenderTarget(), fTime, fPoint(XOFFSET + 32 * m_mD2DGif["opendoor2"].GetPosition().y + 16, YOFFSET + 32 * m_mD2DGif["opendoor2"].GetPosition().x + 16), fVector(32, 32));
		m_mD2DGif["opendoor3"].Render(D2DC.pRenderTarget(), fTime, fPoint(XOFFSET + 32 * m_mD2DGif["opendoor3"].GetPosition().y + 16, YOFFSET + 32 * m_mD2DGif["opendoor3"].GetPosition().x + 16), fVector(32, 32));
		m_mD2DGif["openjail"].Render(D2DC.pRenderTarget(), fTime, fPoint(XOFFSET + 32 * m_mD2DGif["openjail"].GetPosition().y + 16, YOFFSET + 32 * m_mD2DGif["openjail"].GetPosition().x + 16), fVector(32, 32));


		//�������ֵı仯
		if (m_gameState == GAME_TIP || m_gameState == GAME_CHECK_MONSTER || m_gameState == GAME_BATTLE_END
			|| m_gameState == GAME_CAPTION || m_gameState == GAME_TRANSITION){
			
			if (m_gameState == GAME_TRANSITION) m_AlphaChangeEffect.fAlphaChange = TransitionAlphaChangeSpeed;
				else m_AlphaChangeEffect.fAlphaChange = AlphaChangeSpeed;
			if (m_AlphaChangeEffect.isIncrease){
				m_AlphaChangeEffect.fAlphaNow += m_AlphaChangeEffect.fAlphaChange;
				if (m_AlphaChangeEffect.fAlphaNow > 1.0f){
					m_AlphaChangeEffect.fAlphaNow = 1.0f;
					m_AlphaChangeEffect.isIncrease = false;
					if (m_gameState == GAME_TRANSITION){
						Hero.SetFloor(m_subState.nFloorToGoto);

					}
				}
			}
			else{
				m_AlphaChangeEffect.fAlphaNow -= m_AlphaChangeEffect.fAlphaChange;
				if (m_AlphaChangeEffect.fAlphaNow < 0.0f){
					m_AlphaChangeEffect.fAlphaNow = 0.0f;
					m_AlphaChangeEffect.isIncrease = true;
					if (m_gameState == GAME_TRANSITION){
						m_gameState = GAME_RUNNING;
					}
				}
			}
		}

		/////////////////////////////////////////
		//
		//		��Ⱦ��ͬ״̬���Ե�����
		// 
		//	��Ⱦ��ͬ״̬���Ե�����
		// 
		//	��Ⱦ��ͬ״̬���Ե�����
		// 
		//		��Ⱦ��ͬ״̬���Ե�����
		//
		////////////////////////////////////////


		//��Ⱦ��Ϸʤ��
		if (m_gameState == GAME_STATE::GAME_WIN){

			if (m_subState.GameWin.Enable){
				float f = fTime - m_subState.GameWin.fTime;
				if (f > 1.0f){
					D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 38, XOFFSET - 17, YOFFSET + 32 * 5 - 55, 0, 0, L"��ϲ�� ��Ӯ��~", D2DRGB(255, 255, 0));
				}
				else{
					D2DC.DrawBmp(m_mD2DImage["flag"], 30, 127, 756, 191, 1.0F, 0, 0, 756, 191);
				}
			}

			//D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 38, XOFFSET - 17, YOFFSET + 32 * 5 + 25, 0, 0, L"һ���ڴ���ʽ���~", D2DRGB(255, 255, 0));
			
			
			
			
		}


		/////////////////
		//��Ⱦ����
		////////////////
		if(m_gameState==GAME_STATE::GAME_TRANSITION)D2DC.DrawBmp(m_mD2DImage["transition"], XOFFSET, YOFFSET, 32 * 14 - 2, 32 * 14 - 2, m_AlphaChangeEffect.fAlphaNow, 0, 0, 800, 800);


		//////////////////////////////////
		//��Ⱦ��ʾ�ı�
		/////////////////////////////////
#ifdef MAP_LARGE
	#define CAPTIONOFFSET 45
#else
	#define CAPTIONOFFSET 0
#endif
		if (m_gameState == GAME_CAPTION){
			D2DC.DrawBmp(m_mD2DImage["caption"], XOFFSET + CAPTIONOFFSET - 24, YOFFSET + 32 * 4 + CAPTIONOFFSET, 400, 38, 1.0F, 0, 0, 400, 38);
			D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 8, XOFFSET + CAPTIONOFFSET, YOFFSET + 32 * 4 + 2 + CAPTIONOFFSET, 0, 0, L"��ȡ", D2DRGB(255, 255, 255));
			D2DC.DrawTextC(L"", FONT_SIZE, XOFFSET + CAPTIONOFFSET + 60, YOFFSET + CAPTIONOFFSET + 32 * 4 + 8, 0, 0, m_subState.csCaptionString, D2DRGB(255, 255, 255));

			D2DC.DrawTextC(L"΢���ź�", FONT_SIZE + 3, XOFFSET + CAPTIONOFFSET + 300, YOFFSET + CAPTIONOFFSET + 32 * 4 + 6, 0, 0, L"-Enter-", D2DRGB(255, 255, 255), m_AlphaChangeEffect.fAlphaNow);
		}

		//////////////////////////////////
		//��Ⱦ�鿴��������
		/////////////////////////////////

#ifdef MAP_LARGE
		if (m_gameState == GAME_CHECK_MONSTER){
			D2DC.DrawBmp(m_mD2DImage["Dback"], XOFFSET, YOFFSET, 32 * 14 - 2, 32 * 14 - 2, 1.0F, 0, 0, 800, 800);
			//��������
			D2DC.DrawTextB(L"΢���ź�", FONT_SIZE + 7, XOFFSET + 32 * 12 - 23, YOFFSET + 32 * 12 + 25, XOFFSET + 32 * 12 + 200, YOFFSET + 32 * 12 + 150, L"-Enter-", false, false, m_AlphaChangeEffect.fAlphaNow);
			//��������
			if (m_subState.sMonsterChecker.nPageNow > 1){
				D2DC.DrawBmp(m_mD2DImage["leftarrow"], XOFFSET + 32 * 12 - 20, YOFFSET + 32 * 12, 25, 25, 1.0F, 0, 0, 50, 50);
			}
			else{
				D2DC.DrawBmp(m_mD2DImage["leftarrow"], XOFFSET + 32 * 12 - 20, YOFFSET + 32 * 12, 25, 25, 0.3F, 0, 0, 50, 50);
			}
			//��������
			if (m_subState.sMonsterChecker.nPageNow < m_subState.sMonsterChecker.nPageCount){
				D2DC.DrawBmp(m_mD2DImage["rightarrow"], XOFFSET + 32 * 12 + 25, YOFFSET + 32 * 12, 25, 25, 1.0F, 0, 0, 50, 50);
				m_subState.sMonsterChecker.nPageItemsCount = 3;
			}
			else{
				D2DC.DrawBmp(m_mD2DImage["rightarrow"], XOFFSET + 32 * 12 + 25, YOFFSET + 32 * 12, 25, 25, 0.3F, 0, 0, 50, 50);
				if (!m_subState.sMonsterChecker.sMonsterIds.size()) m_subState.sMonsterChecker.nPageItemsCount = 0;
				else if (m_subState.sMonsterChecker.sMonsterIds.size() % 3 == 0) m_subState.sMonsterChecker.nPageItemsCount = 3;
				else  m_subState.sMonsterChecker.nPageItemsCount = m_subState.sMonsterChecker.sMonsterIds.size() % 3;
			}

#define LARGE_FONT_SIZE FONT_SIZE+1
			//����
			//_stprintf_s(wBuff,L"����%s",)
			it = m_subState.sMonsterChecker.sMonsterIds.begin();
			for (i = 1; i < m_subState.sMonsterChecker.nPageNow; i++){
				it++;
				it++;
				it++;
			}

			for (i = 0; i < m_subState.sMonsterChecker.nPageItemsCount; i++){
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 17, YOFFSET + 28 - 6 + 136 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));
				D2DC.DrawRectangle(XOFFSET + 21 - 1, YOFFSET + 57 + 4 + 136 * i - 1, XOFFSET + 21 + 32 + 1, YOFFSET + 57 + 4 + 136 * i + 32 + 1, 2.0F);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 65, YOFFSET + 60 - 6 + 136 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 128, YOFFSET + 60 - 6 + 136 * i, 0, 0, L"������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 205, YOFFSET + 60 - 6 + 136 * i, 0, 0, L"������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 285, YOFFSET + 60 - 6 + 136 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));

				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 65, YOFFSET + 107 - 6 + 136 * i, 0, 0, L"��������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 159, YOFFSET + 107 - 6 + 136 * i, 0, 0, L"�����˺�:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 251, YOFFSET + 107 - 6 + 136 * i, 0, 0, L"Exp:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 308, YOFFSET + 107 - 6 + 136 * i, 0, 0, L"Gold:", D2DRGB(255, 255, 255));

				mBuff[i] = m_mMonster[*it];
				_stprintf_s(wBuff, L"%s", mBuff[i].Name);

				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 65, YOFFSET + 28 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(221, 253, 210));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].HP);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 65, YOFFSET + 83 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(102, 255, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Attack);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 128, YOFFSET + 83 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(200, 51, 200));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Defend);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 205, YOFFSET + 83 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(255, 153, 102));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Swift);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 285, YOFFSET + 83 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(0, 153, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Combo);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 65, YOFFSET + 135 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(0, 147, 196));
				if (ComputeHarm(*it) == -1)_stprintf_s(wBuff, L"%s", L"�޷�����");
					else _stprintf_s(wBuff, L"%-3d", ComputeHarm(*it));
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 159, YOFFSET + 135 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(255, 0, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Exp);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 251, YOFFSET + 135 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(102, 255, 255));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Gold);
				D2DC.DrawTextC(L"�����������", LARGE_FONT_SIZE, XOFFSET + 308, YOFFSET + 135 - 6 + 136 * i, 0, 0, wBuff, D2DRGB(255, 255, 0));

				strcpy_s(cBuff, mBuff[i].IDString.data());
				if (bPace)strcat_s(cBuff, "_1");
				else strcat_s(cBuff, "_2");
				D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 21, YOFFSET + 61 + 136 * i, 32, 32, 1.0F, 0, 0, 32, 32);

				it++;
			}


		}
#else
		if (m_gameState == GAME_CHECK_MONSTER){
			D2DC.DrawBmp(m_mD2DImage["Dback"], XOFFSET, YOFFSET, 32*11-2, 32*11-2, 1.0F, 0, 0, 800, 800);
			//��������
			D2DC.DrawTextB(L"΢���ź�", FONT_SIZE + 3, XOFFSET + 32 * 9 - 11, YOFFSET + 32 * 9 + 31, XOFFSET + 32 * 12 + 200, YOFFSET + 32 * 12 + 150, L"-Enter-", false, false, m_AlphaChangeEffect.fAlphaNow);
			if (m_sMonsterChecker.nPageNow > 1){
				D2DC.DrawBmp(m_mD2DImage["leftarrow"], XOFFSET + 32 * 9 - 4, YOFFSET + 32 * 9 + 13, 18, 18, 1.0F, 0, 0, 50, 50);
			}
			else{
				D2DC.DrawBmp(m_mD2DImage["leftarrow"], XOFFSET + 32 * 9 - 4, YOFFSET + 32 * 9+13, 18, 18, 0.3F, 0, 0, 50, 50);
			}
			//��������
			if (m_sMonsterChecker.nPageNow < m_sMonsterChecker.nPageCount){
				D2DC.DrawBmp(m_mD2DImage["rightarrow"], XOFFSET + 32 * 9 + 31, YOFFSET + 32 * 9 + 13, 18, 18, 1.0F, 0, 0, 50, 50);
				m_sMonsterChecker.nPageItemsCount = 3;
			}else{
				D2DC.DrawBmp(m_mD2DImage["rightarrow"], XOFFSET + 32 * 9 + 31, YOFFSET + 32 * 9 + 13, 18, 18, 0.3F, 0, 0, 50, 50);
				if (!m_sMonsterChecker.sMonsterIds.size()) m_sMonsterChecker.nPageItemsCount = 0;
				else if (m_sMonsterChecker.sMonsterIds.size()%3==0) m_sMonsterChecker.nPageItemsCount = 3;
				else  m_sMonsterChecker.nPageItemsCount = m_sMonsterChecker.sMonsterIds.size() % 3;

			}
			it = m_sMonsterChecker.sMonsterIds.begin();
			for (i = 1; i < m_sMonsterChecker.nPageNow; i++){
				it++;
				it++;
				it++;
			}

			for (i = 0; i < m_sMonsterChecker.nPageItemsCount; i++){
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 17 * 0.8, YOFFSET + 22 * 0.8 + 107 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));
				D2DC.DrawRectangle(XOFFSET + 21 * 0.8 - 2 - 1, YOFFSET + 61 * 0.8 + 2 + 107 * i - 1, XOFFSET + 21 * 0.8 - 2 + 32 + 1, YOFFSET + 61 * 0.8 + 2+ 107 * i + 32 + 1, 2.0F);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 65 * 0.8, YOFFSET + 54 * 0.8 + 107 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 128 * 0.8, YOFFSET + 54 * 0.8 + 107 * i, 0, 0, L"������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 205 * 0.8, YOFFSET + 54 * 0.8 + 107 * i, 0, 0, L"������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 285 * 0.8, YOFFSET + 54 * 0.8 + 107 * i, 0, 0, L"����:", D2DRGB(255, 255, 255));

				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 65 * 0.8, YOFFSET + 101 * 0.8 + 107 * i, 0, 0, L"��������:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 159 * 0.8, YOFFSET + 101 * 0.8 + 107 * i, 0, 0, L"�����˺�:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 251 * 0.8, YOFFSET + 101 * 0.8 + 107 * i, 0, 0, L"Exp:", D2DRGB(255, 255, 255));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 308 * 0.8, YOFFSET + 101 * 0.8 + 107 * i, 0, 0, L"Gold:", D2DRGB(255, 255, 255));

				mBuff[i] = m_mMonster[*it];
				_stprintf_s(wBuff, L"%s", mBuff[i].Name);

				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 65 * 0.8, YOFFSET + 22 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(221, 253, 210));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].HP);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 65 * 0.8, YOFFSET + 77 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(102, 255, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Attack);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 128 * 0.8, YOFFSET + 77 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(200, 51, 200));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Defend);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 205 * 0.8, YOFFSET + 77 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(255, 153, 102));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Swift);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 285 * 0.8, YOFFSET + 77 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(0, 153, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Combo);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 65 * 0.8, YOFFSET + 129 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(0, 147, 196));
				if (ComputeHarm(*it) == -1)_stprintf_s(wBuff, L"%s", L"�޷�����");
				else _stprintf_s(wBuff, L"%-3d", ComputeHarm(*it));
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 159 * 0.8, YOFFSET + 129 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(255, 0, 0));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Exp);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 251 * 0.8, YOFFSET + 129 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(102, 255, 255));
				_stprintf_s(wBuff, L"%-3d", mBuff[i].Gold);
				D2DC.DrawTextC(L"�����������", FONT_SIZE, XOFFSET + 308 * 0.8, YOFFSET + 129 * 0.8 + 107 * i, 0, 0, wBuff, D2DRGB(255, 255, 0));

				strcpy_s(cBuff, mBuff[i].IDString.data());
				if (bPace)strcat_s(cBuff, "_1");
				else strcat_s(cBuff, "_2");
				D2DC.DrawBmp(m_mD2DImage[cBuff], XOFFSET + 21 * 0.8 - 2, YOFFSET + 61 * 0.8+2 + 107 * i, 32, 32, 1.0F, 0, 0, 32, 32);

				it++;
			}
		}


#endif

		//////////////////////////////////
		//��Ⱦ��ͣPause
		/////////////////////////////////
#ifdef MAP_LARGE
		if (m_gameState == GAME_PAUSE){
			D2DC.DrawBmp(m_mD2DImage["pause"], -10, -75, 554 * 1.3, 520 * 1.3, 0.6F, 0, 0, 800, 800);
			D2DC.DrawTextB(L"΢���ź�", 35, XOFFSET + 235, YOFFSET + 265, XOFFSET + 207 + 200, YOFFSET + 225 + 150, L"��P������", false, false, 0.8F);
		}
#else
		if (m_gameState == GAME_PAUSE){
			D2DC.DrawBmp(m_mD2DImage["pause"], 25, -40, 554, 520, 0.6F, 0, 0, 800, 800);
			D2DC.DrawTextB(L"΢���ź�", 22,  XOFFSET + 207, YOFFSET + 225,XOFFSET + 207 + 200, YOFFSET + 225 + 150, L"��P������", false,false, 0.8F);
		}
#endif
		////////////////////////////////////
		//
		// ��Ⱦ�Ի�
		//
		////////////////////////////////////

#ifdef MAP_LARGE 
#define TALKOFFSET 32*1.5
#else
#define TALKOFFSET 0	
#endif
		if (m_gameState == GAME_TIP){
			//�Ի���Ŀ�
			D2DC.DrawBmp(m_mD2DImage["talkback"], TALKOFFSET + XOFFSET + 45, YOFFSET + 32, 261, 132, 1.0F, 0, 0, 261, 132);

			//��������
			D2DC.DrawTextB(L"΢���ź�", FONT_SIZE + 1, TALKOFFSET + XOFFSET + 237, YOFFSET + 135, TALKOFFSET + XOFFSET + 237 + 100, YOFFSET + 135 + 150, L"-Enter-", false, false, m_AlphaChangeEffect.fAlphaNow);


			//̸������
			//����˭̸��
			if (ConversationWithNow._x <0){

			}
			//�͹���̸��
			else if (m_map[Hero.GetFloor()].Block[ConversationWithNow._x][ConversationWithNow._y]>0
				&& m_map[Hero.GetFloor()].Block[ConversationWithNow._x][ConversationWithNow._y] <= (char)MONSTER_COUNT){
				sprintf_s(cBuff, "Monster%d", m_map[Hero.GetFloor()].Block[ConversationWithNow._x][ConversationWithNow._y]);
				if (bPace)strcat_s(cBuff, "_1");
				else strcat_s(cBuff, "_2");
				D2DC.DrawBmp(m_mD2DImage[cBuff], TALKOFFSET + XOFFSET + 61, YOFFSET + 13 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
			}
			else{
				switch (m_map[Hero.GetFloor()].Block[ConversationWithNow._x][ConversationWithNow._y]){
				case (char)71:
					strcpy_s(cBuff, "merchant");
					if (bPace)strcat_s(cBuff, "_2");
					else strcat_s(cBuff, "_1");
					D2DC.DrawBmp(m_mD2DImage[cBuff], TALKOFFSET + XOFFSET + 61, YOFFSET + 13 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)72:
					strcpy_s(cBuff, "oldman");
					if (bPace)strcat_s(cBuff, "_2");
					else strcat_s(cBuff, "_1");
					D2DC.DrawBmp(m_mD2DImage[cBuff], TALKOFFSET + XOFFSET + 61, YOFFSET + 13 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)73:
					strcpy_s(cBuff, "thief");
					if (bPace)strcat_s(cBuff, "_1");
					else strcat_s(cBuff, "_2");
					D2DC.DrawBmp(m_mD2DImage[cBuff], TALKOFFSET + XOFFSET + 61, YOFFSET + 13 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
					break;
				case (char)74:
					strcpy_s(cBuff, "fairy");
					if (bPace)strcat_s(cBuff, "_1");
					else strcat_s(cBuff, "_2");
					D2DC.DrawBmp(m_mD2DImage[cBuff], TALKOFFSET + XOFFSET + 61, YOFFSET + 13 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
					break;

				}

			}

			//�Ի��ı���

			_tcscpy_s(wBuff, ConversationWithNow.sTitle);
			//wBuff[ConversationWithNow.sTitle.GetLength()] = 0;

			D2DC.DrawTextB(L"�����������", FONT_SIZE + 3, TALKOFFSET + XOFFSET + 170, YOFFSET + 45, TALKOFFSET + XOFFSET + 170 + 150, YOFFSET + 103 + 100, wBuff);

			//�Ի�������
			if (ConversationWithNow.vSentences.size() == 1){
				_tcscpy_s(wBuff, ConversationWithNow.vSentences[0]);
				//wBuff[ConversationWithNow.vSentences[0].GetLength()] = 0;
				D2DC.DrawTextB(L"΢���ź�", FONT_SIZE, TALKOFFSET + XOFFSET + 110, YOFFSET + 70, TALKOFFSET + XOFFSET + 110 + 300, YOFFSET + 70 + 250, wBuff);


			}
			else if (ConversationWithNow.vSentences.size() > 1){


			}


		}

		////////////////////////////////////
		//
		// ��Ⱦս������
		//
		////////////////////////////////////
		if (m_gameState == GAME_STATE::GAME_BATTLE || m_gameState == GAME_STATE::GAME_BATTLE_END || m_gameState == GAME_STATE::GAME_OVER){

#define BATTLEOFFSET 0//52
#define BATTLE_HERO_TEXT_LEFT 142
#define BATTLE_HERO_TEXT_TOP 125
#define BATTLE_HERO_DATA_LEFT 82

#define BATTLE_MONSTER_TEXT_LEFT 52
#define BATTLE_MONSTER_TEXT_TOP 125
#define BATTLE_MONSTER_DATA_LEFT 113


			i = 0;


			//����ͼ
			D2DC.DrawBmp(m_mD2DImage["battleback"], BATTLEOFFSET+XOFFSET -18, YOFFSET + 96, 381, 125,1.0F,0,0,381,125);

			//�󷽿�
			D2DC.DrawRectangle(BATTLEOFFSET + XOFFSET - 18 - 1, YOFFSET + 96 - 1, BATTLEOFFSET + XOFFSET - 18 + 381 + 1, YOFFSET + 96 + 125 + 1, 3.0F);
			

			//С����
			D2DC.DrawRectangle(BATTLEOFFSET + XOFFSET + 6 - 1, YOFFSET + 96 + 32 - 1, BATTLEOFFSET + XOFFSET + 6 + 32 + 1, YOFFSET + 96 + 64 + 1, 2.0F);
			D2DC.DrawRectangle(BATTLEOFFSET + XOFFSET + 305 - 1, YOFFSET + 96 + 32 - 1, BATTLEOFFSET + XOFFSET + 305 + 32 + 1, YOFFSET + 96 + 64 + 1, 2.0F);

			//Ӣ��
			D2DC.DrawBmp(m_mD2DImage["hero1d"], BATTLEOFFSET + XOFFSET + 305, YOFFSET + 96 + 32, 32, 32, 1.0F, 0, 0, 32, 32);
			
			//����			
			strcpy_s(cBuff, m_mMonster[(int)BattleWithNow.Monster].IDString.data());
			if(bPace)strcat_s(cBuff, "_1");
			else strcat_s(cBuff, "_2");
			D2DC.DrawBmp(m_mD2DImage[cBuff], BATTLEOFFSET + XOFFSET + 6, YOFFSET + 96 + 32, 32, 32, 1.0F, 0, 0, 32, 32);


#define DRAW_NEXT_BATTLE_HERO_DATA(value) 		_stprintf_s(wBuff, L"%d", value); 	D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + BATTLE_HERO_DATA_LEFT, YOFFSET + BATTLE_HERO_TEXT_TOP + TITLE_SPACE*i++, BATTLEOFFSET + XOFFSET + BATTLE_HERO_DATA_LEFT + 150, YOFFSET + BATTLE_HERO_TEXT_TOP + TITLE_SPACE*i + 100, wBuff,true);
#define DRAW_NEXT_BATTLE_HERO_TEXT(value) 	_stprintf_s(wBuff, value);	D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + BATTLE_HERO_TEXT_LEFT, YOFFSET + BATTLE_HERO_TEXT_TOP + TITLE_SPACE*i++, BATTLEOFFSET + XOFFSET + BATTLE_HERO_TEXT_LEFT + 150, YOFFSET + BATTLE_HERO_TEXT_TOP + TITLE_SPACE*i + 100, wBuff,true);
#define DRAW_NEXT_BATTLE_MONSTER_DATA(value) 		_stprintf_s(wBuff, L"%d", value); 	D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + BATTLE_MONSTER_DATA_LEFT, YOFFSET + BATTLE_MONSTER_TEXT_TOP + TITLE_SPACE*i++, BATTLEOFFSET + XOFFSET + BATTLE_MONSTER_DATA_LEFT + 150, YOFFSET + BATTLE_MONSTER_TEXT_TOP + TITLE_SPACE*i + 100, wBuff);
#define DRAW_NEXT_BATTLE_MONSTER_TEXT(value) 	_stprintf_s(wBuff, value);	D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + BATTLE_MONSTER_TEXT_LEFT, YOFFSET + BATTLE_MONSTER_TEXT_TOP + TITLE_SPACE*i++, BATTLEOFFSET + XOFFSET + BATTLE_MONSTER_TEXT_LEFT + 150, YOFFSET + BATTLE_MONSTER_TEXT_TOP + TITLE_SPACE*i + 100, wBuff);


			DRAW_NEXT_BATTLE_HERO_DATA(Hero.GetHP());
			DRAW_NEXT_BATTLE_HERO_DATA(Hero.GetAttack());
			DRAW_NEXT_BATTLE_HERO_DATA(Hero.GetDefense());
			DRAW_NEXT_BATTLE_HERO_DATA(Hero.GetSwift());
			i = 0;
			DRAW_NEXT_BATTLE_HERO_TEXT(L":����");
			DRAW_NEXT_BATTLE_HERO_TEXT(L":������");
			DRAW_NEXT_BATTLE_HERO_TEXT(L":������");
			DRAW_NEXT_BATTLE_HERO_TEXT(L":����");
			i = 0;
			DRAW_NEXT_BATTLE_MONSTER_DATA(BattleWithNow.HP);
			DRAW_NEXT_BATTLE_MONSTER_DATA(BattleWithNow.Attack);
			DRAW_NEXT_BATTLE_MONSTER_DATA(BattleWithNow.Defense);
			DRAW_NEXT_BATTLE_MONSTER_DATA(BattleWithNow.Swift);
			i = 0;
			DRAW_NEXT_BATTLE_MONSTER_TEXT(L"����:");
			DRAW_NEXT_BATTLE_MONSTER_TEXT(L"������:");
			DRAW_NEXT_BATTLE_MONSTER_TEXT(L"������:");
			DRAW_NEXT_BATTLE_MONSTER_TEXT(L"����:");



			_stprintf_s(wBuff, L"VS");	
			D2DC.DrawTextB(L"���������׭", 20, BATTLEOFFSET + XOFFSET + 155, YOFFSET + 100, BATTLEOFFSET + XOFFSET + 155 + 150, YOFFSET + 100 + 100, wBuff);
			
			_stprintf_s(wBuff, L"%s", BattleWithNow.MonsterName);
			D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + 10, YOFFSET + 103, BATTLEOFFSET + XOFFSET + 10 + 150, YOFFSET + 103 + 100, wBuff);

			_stprintf_s(wBuff, L"����");
			D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + 305, YOFFSET + 103, BATTLEOFFSET + XOFFSET + 305 + 150, YOFFSET + 103 + 100, wBuff);

			if (m_gameState == GAME_STATE::GAME_BATTLE){
				_stprintf_s(wBuff, L"����(Q)");
				D2DC.DrawTextB(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + 300, YOFFSET + 196, BATTLEOFFSET + XOFFSET + 300 + 150, YOFFSET + 196 + 100, wBuff, false, true);
			}

			//������Ч
			m_mD2DGif["heroslash"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 21, YOFFSET + 143), fVector(53, 53));
			
			m_mD2DGif["heroslashb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 21, YOFFSET + 143), fVector(50, 50));


			m_mD2DGif["fist"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 323, YOFFSET + 143), fVector(48, 48));
			m_mD2DGif["fistb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 323, YOFFSET + 143), fVector(55, 55));

			m_mD2DGif["water"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(58, 58));
			m_mD2DGif["waterb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 - 13 ), fVector(63, 63));

			m_mD2DGif["sword"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(53, 53));

			m_mD2DGif["swordb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321+1, YOFFSET + 143+1), fVector(57, 57));


			m_mD2DGif["suck"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(48, 48));
			m_mD2DGif["suckb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-3, YOFFSET + 143+1), fVector(60 ,60));

			m_mD2DGif["flash"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(52, 52));

			m_mD2DGif["explode"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(75, 75));
			m_mD2DGif["explodeb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 -12), fVector(75, 75));


			m_mD2DGif["poision"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-3 , YOFFSET + 143), fVector(50, 60));

			m_mD2DGif["nuclear"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143-5), fVector(90, 60));
			m_mD2DGif["nuclearb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 - 12), fVector(75, 75));

			m_mD2DGif["greenlaser"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-2, YOFFSET + 143+3 ), fVector(63, 63));

			m_mD2DGif["laser"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-2, YOFFSET + 143+3 ), fVector(63, 63));

			m_mD2DGif["magic"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 ), fVector(53, 53));
			m_mD2DGif["magicb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 - 12), fVector(75, 75));

			m_mD2DGif["firesword"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(53, 53));

			m_mD2DGif["fire"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 ), fVector(400, 400));

			m_mD2DGif["fireb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321 , YOFFSET + 143-20), fVector(300,300));

			m_mD2DGif["fireswordb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-35, YOFFSET + 143), fVector(200, 200));

			m_mD2DGif["ice"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321+10, YOFFSET + 143-10), fVector(300, 230));


			m_mD2DGif["iceb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(1000, 1000));

			m_mD2DGif["curse"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143), fVector(500, 500));

			m_mD2DGif["curseb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321+5, YOFFSET + 143), fVector(500, 500));

			m_mD2DGif["barrage"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321-40, YOFFSET + 143-30), fVector(400, 400));
			
			m_mD2DGif["barrageb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 - 10), fVector(650, 650));

			m_mD2DGif["hit"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321, YOFFSET + 143 - 10), fVector(400, 400));

			m_mD2DGif["fog"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321  , YOFFSET + 143 + 24  ), fVector(400, 400));

			m_mD2DGif["fogb"].Render(D2DC.pRenderTarget(), fTime, fPoint(BATTLEOFFSET + XOFFSET + 321 + DEBUG_BATTLE_X, YOFFSET + 143 - 20+ DEBUG_BATTLE_Y), fVector(300, 300));

			//��Ⱦmiss
			if (m_subState.HeroMiss.Enable){
				float f = fTime - m_subState.HeroMiss.fTime;
				if (f > 0.3f){
					m_subState.HeroMiss.Enable = false;
				}
				else{
					D2DC.DrawTextC(L"��������ع��", FONT_SIZE + 12, XOFFSET + 321 - 42 + DEBUG_BATTLE_X, YOFFSET + 143 - 11 - f * 60 + DEBUG_BATTLE_Y, 0, 0, "MISS!!", D2DRGB(255, 0, 0), 1.0 - f*3.3);
				}
			}


			if (m_subState.MonsterMiss.Enable){
				float f = fTime - m_subState.MonsterMiss.fTime;
				if (f > 0.3f){
					m_subState.MonsterMiss.Enable = false;
				}
				else{
					D2DC.DrawTextC(L"��������ع��", FONT_SIZE + 12, XOFFSET + 24 - 42 + DEBUG_BATTLE_X, YOFFSET + 143 - 11 - f * 60 + DEBUG_BATTLE_Y, 0, 0, "MISS!!", D2DRGB(255, 0, 0), 1.0 - f*3.3);
				}
			}

		}
		///////////////////
		//��Ⱦս������
		//////////////////
		if (m_gameState == GAME_STATE::GAME_BATTLE_END){


			D2DC.DrawBmp(m_mD2DImage["battleendback"], BATTLEOFFSET + XOFFSET - 18, YOFFSET + 96 + 125, 381, 32, 1.0F, 0, 0, 381, 32);
			D2DC.DrawRectangle(BATTLEOFFSET + XOFFSET - 18 - 1, YOFFSET + 96 + 125 + 1, BATTLEOFFSET + XOFFSET - 18 + 381 + 1, YOFFSET + 96 + 125 + 32 + 2, 3.0F);
			D2DC.DrawTextC(L"��������ع��", FONT_SIZE + 6, BATTLEOFFSET + XOFFSET + 10, YOFFSET + 229, 0, 0, L"ʤ��!!!", D2DRGB(255, 255, 255));
			_stprintf_s(wBuff, L"����ֵ:%d", BattleWithNow.Exp);
			D2DC.DrawTextC(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + 190, YOFFSET + 229, 0, 0, wBuff, D2DRGB(255, 255, 255));

			_stprintf_s(wBuff, L"���:%d", BattleWithNow.Gold);
			D2DC.DrawTextC(L"�����������", FONT_SIZE, BATTLEOFFSET + XOFFSET + 275, YOFFSET + 229, 0, 0, wBuff, D2DRGB(255, 255, 255));
			D2DC.DrawTextB(L"΢���ź�", FONT_SIZE + 1, BATTLEOFFSET + XOFFSET + 300, YOFFSET + 196, BATTLEOFFSET + XOFFSET + 300 + 150, YOFFSET + 196 + 100, L"-Enter-", false, false, m_AlphaChangeEffect.fAlphaNow);

		}

		//��Ⱦ��Ϸ����
		if (m_gameState == GAME_STATE::GAME_OVER){

			if (m_subState.GameOver.Enable){
				float f = fTime - m_subState.GameOver.fTime;
				if (f > 9.0f){
					m_subState.GameOver.Enable = false;
				}
				else if (f > 5.5f){
					D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 62, XOFFSET - 17, YOFFSET + 32 * 5 +20+20-f * 10, 0, 0, L"Game Over~", D2DRGB(255, 0, 0), 1.0f - fabs(f - 5.5f) / 3.5f);
				}
				else if (f > 3.5f){
					D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 62, XOFFSET - 17, YOFFSET + 32 * 5 +20- 3.5 * 10, 0, 0, L"Game Over~", D2DRGB(255, 0, 0), 1.0f);
				}
				else{
					D2DC.DrawTextC(L"�����ΰѫӲ�������ֿ�", FONT_SIZE + 62, XOFFSET - 17, YOFFSET + 32 * 5 +20- f * 10, 0, 0, L"Game Over~", D2DRGB(255, 0, 0), 1.0f - fabs(f-3.5f)/3.5f);
				}
			}
		}


		

		break;

	case GAME_POP_MENU:
		break;
	case GAME_AUDIO_MENU:
		break;
	case GAME_VIDEO_MENU:
		break;

	default:
		break;
	}

	D2DC.EndDraw();
	
	ReleaseSemaphore(RenderMutex, 1, NULL);

	return true;
}

void CGame::SetInstance(HINSTANCE instance){
	m_Instance = instance;
}