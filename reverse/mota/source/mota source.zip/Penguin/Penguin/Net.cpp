#include"stdafx.h"
#include <string>
#include "Net.h"

#pragma comment(lib,"ws2_32.lib")
using namespace std;

SOCKET CNet::m_clientSocket = 0;

CNet::CNet():m_nServerPort(797), m_nSendFrequency(DEFAULT_SEND_FREQUENCY){
	if (!Init()) CNet::~CNet();
}


CNet::~CNet(){

	DisConnect();
	WSACleanup();
}


DWORD WINAPI CNet::ReceiveMessageThread(LPVOID IpParameter){
	CHAR receiveBuf[MAX_RECEIVE_BUFF] = {'\0'};

	do{
		recv(m_clientSocket, receiveBuf, 200, 0);
		if (recv > 0) {
			//SYSTEMTIME		sTime;
			//GetSystemTime(&sTime);
			//printf("%d:%d:%d--", sTime.wMinute, sTime.wSecond, sTime.wMilliseconds);
			//printf("Recv:%s\n", receiveBuf);
			Receive(receiveBuf);
		}
	} while (recv > 0);
	//Decrypt(receiveBuf);//����

	return 0;
}

bool	CNet::Init(){
	strcpy_s(m_cServerIp, "139.224.12.201");

	int err;
	WORD versionRequired;
	WSADATA wsaData;
	versionRequired = MAKEWORD(1, 1);
	err = WSAStartup(versionRequired, &wsaData);//Э���İ汾��Ϣ
	if (!err)    {
#ifdef _DEBUG_
		OutputDebugString(L"�ͻ���Ƕ�����Ѿ���!");
#endif
		//printf("�ͻ���Ƕ�����Ѿ���!\n");
	}
	else{
		//printf("ERROR:�ͻ��˵�Ƕ���ִ�ʧ��!\n");
		_ERROR(TEXT("�ͻ��˵�Ƕ���ִ�ʧ��!"));
		return false;//����
	}
	m_clientSocket = socket(AF_INET, SOCK_STREAM, 0);

	const char chOpt = 1;

	return true;
}

bool	CNet::SetServerIP(LPSTR IP){
	strcpy_s(m_cServerIp, IP);
	return true;
}
bool CNet::SetServerPort(int nPort){
	m_nServerPort = nPort;
	return true;
}
bool CNet::SetSendFrequency(int nFrequency){
	m_nSendFrequency = nFrequency;
	return true;
}

bool CNet::SetDelayMs(int nDelayMs){
	m_nDelayMs = nDelayMs;
	return true;
}


int CNet::GetDelayMs(){
	return m_nDelayMs;
}

bool CNet::Connect(){

	SOCKADDR_IN clientsock_in;
	clientsock_in.sin_addr.S_un.S_addr = inet_addr(m_cServerIp);
	clientsock_in.sin_family = AF_INET;
	clientsock_in.sin_port = htons(m_nServerPort);

	//bind(clientSocket,(SOCKADDR*)&clientsock_in,strlen(SOCKADDR));//ע�����������
	//listen(clientSocket,5);
	int nc=connect(m_clientSocket, (SOCKADDR*)&clientsock_in, sizeof(SOCKADDR));//��ʼ����
	
	if (nc){
		INFO(TEXT("���ӷ�������ʱ"));
		return false;
	}



	//HANDLE receiveThread = CreateThread(NULL, 0, ReceiveMessageThread, (LPVOID)recvType, 0, NULL);
	//����һ�������߳�
	HANDLE receiveThread = CreateThread(NULL, 0, ReceiveMessageThread, NULL, 0, NULL);
	

	return true;
}

bool CNet::Encrypt(LPSTR String, Algorithm algorithm){

	switch (algorithm)
	{
	case NO_ENCRYPTION:

		break;
	default:
		break;
	}


	return true;
}
/////////////////////////////////////
//										    //
//										    //
//		������������е��� ��Ҫ�޸ģ���	    //
//										    //
//										    //
/////////////////////////////////////
bool CNet::Send(vector<DATABLOCK> vSendData, float fTime){
	



	/*
	static DATABLOCK db[5];
	static int i = 0;
	*/static CHAR	 sendBuf[MAX_SEND_BUFF] = { '\0' };
/*
	
	if (fTime != 0){
		static float fLastTime2 = 0;
		if (fTime - fLastTime2 < 1.0f){ 
			
			return true; 
		}
		else fLastTime2 = fTime;

	}
//	char receiveBuf[MAX_RECEIVE_BUFF];
	//CHAR	 sendBuf[MAX_SEND_BUFF] = {'\0'};

	//static int ii = 0;
	//sprintf_s(sendBuf, "hello,this is client-%d", ++ii);
	
	*/int nCount = vSendData.size();
	for (int i = 0; i < nCount; i++){
		if (i) strcat_s(sendBuf, "&");
		
		strcat_s(sendBuf, vSendData[i].cKey);

		strcat_s(sendBuf, "=");

		strcat_s(sendBuf, vSendData[i].cValue);

	}

	Encrypt(sendBuf);

	if (fTime != 0){
		static float fLastTime = 0;
		if (fTime - fLastTime < 1 / (m_nSendFrequency*1.0f)){
			strcat_s(sendBuf, "#"); return true;
		}
		else fLastTime = fTime;

	}
	


	Send(sendBuf);
	memset(sendBuf, 0, sizeof(sendBuf));
	/*

#ifdef _DEBUG_
	//DEBUG(s);//����Ƿ��͵ĳ���
#endif
		//recv(clientSocket,receiveBuf,101,MSG_PEEK);
		//printf("Recv:%s\n",receiveBuf);
	
	//closesocket(clientSocket);
	//WSACleanup();
	*/
	return true;

	
}
/////////////////////////////////////
//										    //
//										    //
//		������������е��� ��Ҫ�޸ģ���	    //
//										    //
//										    //
/////////////////////////////////////



int CNet::Send(LPSTR lpSendString){

	int s = send(m_clientSocket, lpSendString, MAX_SEND_BUFF, 0);

	return s;
}

void CNet::Receive(LPSTR lpRecvString){

	Game.OnRecvMessage(lpRecvString);

}

void CNet::DisConnect(){
	closesocket(m_clientSocket);
}