#include "stdafx.h"
#include "window.h"

#ifndef _SERVER_

CWindow::CWindow(){}

CWindow::~CWindow(){}

#endif