#include "stdafx.h"
#include "Behaviour.h"


CBehaviour::CBehaviour(void){


}
CBehaviour::~CBehaviour(void){




}

#define DBGSpeed 500

bool CBehaviour::Execute(float fTime){


	return true;
}


bool CBehaviour::Move(CPlayer &oPlayer, float fTime){


	return true;
}
