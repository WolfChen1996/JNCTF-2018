#include <WINSOCK2.H>
#include <stdio.h>
#include <string.h>
#include <Windows.h>
#include "CommonHead.h"

#ifndef _H_NET_H

#define _H_NET_H
#pragma once

#define MAX_SEND_BUFF 200
#define MAX_RECEIVE_BUFF  300
#define DEFAULT_SEND_FREQUENCY 1


enum Algorithm{
	NO_ENCRYPTION = 0, //������
	AES,
	BASE64
};

#ifdef _CLIENT_
//�ͻ���
class CNet{
public:
	//lpResPath����:TEXT("animation/1.bmp")
	CNet();
	~CNet();

	static DWORD WINAPI ReceiveMessageThread(LPVOID IpParameter);//�����߳�
	

	bool	SetServerIP(LPSTR IP);
	bool SetServerPort(int nPort);
	bool SetSendFrequency(int nFrequency);
	bool SetDelayMs(int nDelayMs);


	int GetDelayMs();


	bool	Init();

	bool Connect();
	
	bool Encrypt(LPSTR String, Algorithm algorithm = NO_ENCRYPTION);//����

	bool Send(vector<DATABLOCK>	vSendData,float fTime=0);

	int Send(LPSTR lpSendString);//���û�д��󷵻ط��͵��ֽ���

	static void Receive(LPSTR lpRecvString);

	void DisConnect();

protected:
	char				m_cServerIp[20];
	int				m_nServerPort;
	int				m_nSendFrequency;//ÿ�뷢�Ͷ��ٴ�
	int				m_nDelayMs;//�ȴ����ٺ���
	BYTE			m_SendBuf[MAX_SEND_BUFF];
	
	static SOCKET	m_clientSocket;
	//vector<DATABLOCK>	m_vSendData;
};


#else
//������


#endif

#endif