#include "stdafx.h"
#include "Living.h"

CLiving::CLiving(){


}
CLiving::~CLiving(){


}

void CLiving::SetMove(bool bMove){
	m_bMoving = bMove;
}

void CLiving::Move(Direction direction, int nUnit){
	switch (direction)
	{
	case up:
		
		m_nPos = Point(m_nPos.x - nUnit, m_nPos.y);
		break;
	case down:
		m_nPos = Point(m_nPos.x + nUnit, m_nPos.y );
		break;
	case left:
		m_nPos = Point(m_nPos.x, m_nPos.y - nUnit);
		break;
	case right:
		m_nPos = Point(m_nPos.x, m_nPos.y + nUnit);
		break;
	/*case up_left:
		m_fPos = fPoint(m_fPos.x - fUnit / sqrt(2.0f), m_fPos.y - fUnit / sqrt(2.0f));
		break;
	case up_right:
		m_fPos = fPoint(m_fPos.x + fUnit / sqrt(2.0f), m_fPos.y - fUnit / sqrt(2.0f));
		break;
	case down_left:
		m_fPos = fPoint(m_fPos.x - fUnit / sqrt(2.0f), m_fPos.y + fUnit / sqrt(2.0f));
		break;
	case down_right:
		m_fPos = fPoint(m_fPos.x + fUnit / sqrt(2.0f), m_fPos.y + fUnit / sqrt(2.0f));
		break;*/
	//case nodirection:
	default:
		break;
	}
	if (direction != nodirection)m_direction = direction;

}
//���ĸ������� �ٶȣ�ÿ���Ӷ��ٵ�λ��
bool CLiving::Walk(Direction direction, float fSpeed, float fTime){
	/*if (m_fLastTime == 0){
		m_fLastTime = fTime;
		return false;
	}*/
	Move(direction, fSpeed  *(fTime - m_fLastTime));
	
	m_fLastTime = fTime;
	//if (direction != nodirection)
	//m_mMoveAnimation[direction].SetPosition( m_nPos);
	return true;
}


bool CLiving::Render(float fTime){

	if (m_bStill){

	}
	else if (m_bRunning){

	}
	else if (m_bMoving){
		 if(m_mMoveAnimation.find(m_direction) != m_mMoveAnimation.end())
			 m_mMoveAnimation[m_direction].Render(D2DC.pRenderTarget(), fTime);
	}

	return true;
}


