#pragma once


unsigned int GetCRC(char *filePath);

void CheckCRC(char *filePath, unsigned int _CRC);
