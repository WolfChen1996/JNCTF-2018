#ifndef _SERVER_

#include <windows.h>

#ifndef _H_WINDOW_H
#define _H_WINDOW_H
#pragma once


class CWindow{
public:
	CWindow();
	~CWindow();

	HWND hWnd;


protected:


};

#endif

#endif