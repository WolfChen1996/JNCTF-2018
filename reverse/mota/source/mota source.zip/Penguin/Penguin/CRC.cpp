#include "stdafx.h"
#include <stdio.h>
#include <inttypes.h>
#include <conio.h> 
#include <stdlib.h>
#include "CRC.h"

#define Poly 0xEDB88320L		//CRC32��׼ ���õ��Ļ�ȡ�ļ�CRC32ֵ���㷨����WINRAR�е�CRC32ֵһ�£��ǳ�ʵ�ð���ֵ���ղء�
static uint32_t crc_tab32[256];	//CRC��ѯ��

static void init_crc32_tab(void);	//����CRC��ѯ��
uint32_t get_crc32(uint32_t crcinit, uint8_t * bs, uint32_t bssize);	//���CRC
uint32_t GetFileCRC(FILE * fd);	//����ļ�CRC

static void init_crc32_tab(void)
{
	int i, j;
	uint32_t crc;

	for (i = 0; i<256; i++)
	{
		crc = (unsigned long)i;
		for (j = 0; j<8; j++)
		{
			if (crc & 0x00000001L)
				crc = (crc >> 1) ^ Poly;
			else
				crc = crc >> 1;
		}
		crc_tab32[i] = crc;
	}
}

uint32_t get_crc32(uint32_t crcinit, uint8_t * bs, uint32_t bssize)
{
	uint32_t crc = crcinit ^ 0xffffffff;

	init_crc32_tab();
	while (bssize--)
		crc = (crc >> 8) ^ crc_tab32[(crc & 0xff) ^ *bs++];

	return crc ^ 0xffffffff;
}

uint32_t GetFileCRC(FILE * fd)
{
	uint32_t size = 1024;
	uint8_t crcbuf[1024];
	uint32_t rdlen;
	uint32_t crc = 0;	//CRC��ʼֵΪ0
	fseek(fd, 0, SEEK_SET);
	while ((rdlen = fread(crcbuf, sizeof(uint8_t), size, fd)) > 0)
		crc = get_crc32(crc, crcbuf, rdlen);

	return crc;
}

unsigned int  GetCRC(char *filePath){
	FILE *fd;
	unsigned int value = 0;


	if ((fd = fopen(filePath, "r")) == NULL)
	{
		//perror("Error:");
		MessageBoxA(0, "�ļ���", "", 0);
		exit(1);
	}
	value = GetFileCRC(fd);
	//printf("CRC: %X\n", value);

	fclose(fd);
	return value;

}

void CheckCRC(char *filePath, unsigned int _CRC){
	if (GetCRC(filePath) != _CRC){
		MessageBoxA(0, "ͯЬ ����flag�ǲ������Ҹ���Ϸ�ļ���Ӵ~", "", 0);
		exit(1);
	}

}
